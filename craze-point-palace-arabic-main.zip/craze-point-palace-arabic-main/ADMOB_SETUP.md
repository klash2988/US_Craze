
# دليل إعداد AdMob للتطبيق

## الخطوات المطلوبة بعد إنشاء حساب AdMob:

### 1. إنشاء حساب AdMob
- انتقل إلى [Google AdMob Console](https://admob.google.com/)
- قم بإنشاء حساب جديد أو استخدم حساب Google موجود
- أضف تطبيقك الجديد

### 2. الحصول على معرفات الإعلانات
بعد إنشاء التطبيق في AdMob، ستحتاج إلى:

#### أ. معرف التطبيق (App ID):
- Android: `ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX`
- iOS: `ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX`

#### ب. معرفات وحدات الإعلانات (Ad Unit IDs):
- إعلان المكافأة (Rewarded Ad): `ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX`
- (اختياري) إعلان البانر: `ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX`
- (اختياري) إعلان الشاشة الكاملة: `ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX`

### 3. تحديث الإعدادات في الكود

#### في ملف `src/config/admob.ts`:
```typescript
export const ADMOB_CONFIG = {
  APP_ID: {
    android: 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX', // ضع معرف Android هنا
    ios: 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX' // ضع معرف iOS هنا
  },
  
  AD_UNITS: {
    REWARDED: {
      android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // معرف إعلان المكافأة Android
      ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX' // معرف إعلان المكافأة iOS
    }
  },
  
  TEST_MODE: false, // غير إلى false عند النشر
};
```

#### في ملف `capacitor.config.ts`:
```typescript
AdMob: {
  appId: 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX', // ضع معرف التطبيق هنا
}
```

### 4. الخطوات التقنية للنشر:

#### أ. بناء التطبيق:
```bash
npm run build
npx cap sync
```

#### ب. للاختبار على Android:
```bash
npx cap run android
```

#### ج. للاختبار على iOS:
```bash
npx cap run ios
```

### 5. ملاحظات مهمة:

#### وضع الاختبار:
- اتركه `TEST_MODE: true` أثناء التطوير والاختبار
- غيره إلى `TEST_MODE: false` عند النشر الحقيقي

#### إعدادات المتجر:
- **Android**: أضف معرف التطبيق في `android/app/src/main/AndroidManifest.xml`
- **iOS**: أضف معرف التطبيق في `ios/App/App/Info.plist`

#### الإذونات:
- سيتم طلب إذن تتبع الإعلانات تلقائياً على iOS
- لا حاجة لإذونات إضافية على Android

### 6. استكشاف الأخطاء:
- تأكد من صحة معرفات الإعلانات
- تحقق من اتصال الإنترنت
- راجع سجلات الجهاز (device logs) للأخطاء
- تأكد من أن التطبيق مسجل بشكل صحيح في AdMob

### 7. الحد الأدنى لعرض الإعلانات:
- قد تحتاج إلى انتظار 24-48 ساعة بعد إعداد AdMob لبدء عرض الإعلانات
- تأكد من أن سياسات AdMob متوافقة مع التطبيق
