
import { useState, useEffect } from 'react';
import { useLanguage } from './useLanguage';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

interface NotificationData {
  lastNotificationDate: string;
  notificationCount: number;
}

export const useNotifications = () => {
  const [hasPermission, setHasPermission] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    requestNotificationPermission();
    scheduleMotivationalNotifications();
  }, []);

  const requestNotificationPermission = async () => {
    try {
      if (Capacitor.isNativePlatform()) {
        // For mobile apps using Capacitor
        const permission = await LocalNotifications.requestPermissions();
        setHasPermission(permission.display === 'granted');
      } else {
        // For web browsers
        if ('Notification' in window) {
          if (Notification.permission === 'default') {
            const permission = await Notification.requestPermission();
            setHasPermission(permission === 'granted');
          } else {
            setHasPermission(Notification.permission === 'granted');
          }
        }
      }
    } catch (error) {
      console.log('Notification permission error:', error);
    }
  };

  const getNotificationData = (): NotificationData => {
    const data = localStorage.getItem('notificationData');
    if (data) {
      return JSON.parse(data);
    }
    return {
      lastNotificationDate: '',
      notificationCount: 0
    };
  };

  const updateNotificationData = (data: NotificationData) => {
    localStorage.setItem('notificationData', JSON.stringify(data));
  };

  const canSendNotification = (): boolean => {
    const data = getNotificationData();
    const today = new Date().toDateString();
    
    if (data.lastNotificationDate !== today) {
      // New day, reset counter
      updateNotificationData({
        lastNotificationDate: today,
        notificationCount: 0
      });
      return true;
    }
    
    return data.notificationCount < 2;
  };

  const sendNotification = async (title: string, body: string, delay: number = 0) => {
    if (!hasPermission || !canSendNotification()) return;

    setTimeout(async () => {
      try {
        if (Capacitor.isNativePlatform()) {
          // Send native notification using Capacitor
          await LocalNotifications.schedule({
            notifications: [
              {
                title,
                body,
                id: Date.now(),
                schedule: { at: new Date(Date.now() + 1000) }, // 1 second from now
                sound: 'default',
                attachments: undefined,
                actionTypeId: '',
                extra: null
              }
            ]
          });
        } else {
          // Send web notification
          const notification = new Notification(title, {
            body,
            icon: '/favicon.ico',
            badge: '/favicon.ico',
            requireInteraction: false,
          });

          // Auto close after 5 seconds
          setTimeout(() => {
            notification.close();
          }, 5000);
        }

        // Update notification count
        const data = getNotificationData();
        updateNotificationData({
          ...data,
          notificationCount: data.notificationCount + 1
        });

      } catch (error) {
        console.log('Error sending notification:', error);
      }
    }, delay);
  };

  const scheduleMotivationalNotifications = () => {
    // Welcome notification after 30 seconds
    setTimeout(() => {
      sendNotification(
        t('welcomeNotificationTitle') || 'مرحباً بك في UC Craze!',
        t('welcomeNotificationBody') || 'ابدأ رحلتك لربح شدات ببجي مجاناً'
      );
    }, 30000);

    // Daily reminder notification after 2 hours
    setTimeout(() => {
      sendNotification(
        t('dailyReminderTitle') || 'لا تنس مكافآتك اليومية!',
        t('dailyReminderBody') || 'شاهد الإعلانات واربح نقاط لسحب الشدات'
      );
    }, 2 * 60 * 60 * 1000); // 2 hours
  };

  return {
    hasPermission,
    sendNotification,
    canSendNotification
  };
};
