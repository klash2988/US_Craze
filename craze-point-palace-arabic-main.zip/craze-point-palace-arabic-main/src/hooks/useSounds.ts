
import { useCallback, useEffect, useState } from 'react';
import { soundLibrary, setupSounds } from '@/utils/soundLibrary';

export const useSounds = () => {
  const [isEnabled, setIsEnabled] = useState(() => {
    return localStorage.getItem('soundsEnabled') !== 'false';
  });

  useEffect(() => {
    setupSounds();
  }, []);

  useEffect(() => {
    localStorage.setItem('soundsEnabled', isEnabled.toString());
  }, [isEnabled]);

  const playSound = useCallback((soundName: keyof typeof soundLibrary) => {
    if (!isEnabled) return;
    
    try {
      const sound = soundLibrary[soundName];
      sound.currentTime = 0; // إعادة تشغيل من البداية
      sound.play().catch(console.warn); // تجاهل الأخطاء الصوتية
    } catch (error) {
      console.warn('Could not play sound:', error);
    }
  }, [isEnabled]);

  const toggleSounds = useCallback(() => {
    setIsEnabled(prev => !prev);
  }, []);

  return {
    playSound,
    isEnabled,
    toggleSounds,
  };
};
