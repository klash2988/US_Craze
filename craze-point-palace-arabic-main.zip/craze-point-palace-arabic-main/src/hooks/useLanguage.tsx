import { useState, useEffect, createContext, useContext, ReactNode } from 'react';

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  ar: {
    // Home Screen
    'ucCraze': 'UC Craze',
    'settings': '⚙️',
    'contentCreator': '🎥 هل أنت صانع محتوى؟',
    'points': 'نقطة',
    'uc': 'شدة',
    'withdrawRequest': '📤 طلب سحب الشدات',
    'watchAd': 'مشاهدة إعلان',
    'dailySpin': 'العجلة اليومية',
    'premiumSpin': 'العجلة المميزة',
    'free': 'مجاني',
    'points3100': '3100 نقطة',
    'downloadApps': 'قم بتنزيل تطبيقاتنا الأخرى وكسب نقاط',
    'comingSoon': 'قريباً',
    'tasksCenter': 'مركز المهام',
    'points300': '300 نقطة',
    'inviteFriends': 'دعوة الأصدقاء',
    'points500': '500 نقطة',
    'technicalSupport': 'دعم فني',
    'contactUs': 'تواصل معنا',
    'ucLeague': 'دوري جنون الشدات',
    // Settings
    'settingsTitle': '⚙️ الإعدادات',
    'darkMode': '🌗 الوضع الليلي',
    'switchToEnglish': '🌐 التبديل إلى الإنجليزية',
    'reportBug': '🐞 الإبلاغ عن مشكلة',
    'appVersion': 'UC Craze v1.0',
    'appDescription': 'تطبيق مجاني لربح شدات ببجي',
    // Toasts
    'maxAdsReached': 'تم الوصول للحد الأقصى',
    'maxAdsDescription': 'لقد شاهدت 50 إعلان اليوم. حاول مرة أخرى غداً!',
    'loadingAd': 'جاري تحميل الإعلان...',
    'pleaseWait': 'يرجى الانتظار',
    'congratulations': 'تهانينا! 🎉',
    'earnedPoints': 'لقد حصلت على 20 نقطة!',
    'devMode': 'وضع المطور مفعل! 🔧',
    'devModeDescription': 'تم إضافة 10000 نقطة و 1000 شدة!',
    // Menu items
    'aboutApp': 'ℹ️ حول التطبيق',
    'privacyPolicy': '🔐 سياسة الخصوصية',
    'termsOfUse': '📄 شروط الاستخدام',
    // Notifications
    'welcomeNotificationTitle': 'مرحباً بك في UC Craze! 🎮',
    'welcomeNotificationBody': 'ابدأ رحلتك لربح شدات ببجي مجاناً',
    'dailyReminderTitle': 'لا تنس مكافآتك اليومية! 🎁',
    'dailyReminderBody': 'شاهد الإعلانات واربح نقاط لسحب الشدات'
  },
  en: {
    // Home Screen
    'ucCraze': 'UC Craze',
    'settings': '⚙️',
    'contentCreator': '🎥 Are you a content creator?',
    'points': 'Points',
    'uc': 'UC',
    'withdrawRequest': '📤 Request UC Withdrawal',
    'watchAd': 'Watch Ad',
    'dailySpin': 'Daily Spin',
    'premiumSpin': 'Premium Spin',
    'free': 'Free',
    'points3100': '3100 Points',
    'downloadApps': 'Download our other apps and earn points',
    'comingSoon': 'Coming Soon',
    'tasksCenter': 'Tasks Center',
    'points300': '300 Points',
    'inviteFriends': 'Invite Friends',
    'points500': '500 Points',
    'technicalSupport': 'Technical Support',
    'contactUs': 'Contact Us',
    'ucLeague': 'UC Craze League',
    // Settings
    'settingsTitle': '⚙️ Settings',
    'darkMode': '🌗 Dark Mode',
    'switchToEnglish': '🌐 Switch to Arabic',
    'reportBug': '🐞 Report Bug',
    'appVersion': 'UC Craze v1.0',
    'appDescription': 'Free app to earn PUBG UC',
    // Toasts
    'maxAdsReached': 'Maximum Reached',
    'maxAdsDescription': 'You have watched 50 ads today. Try again tomorrow!',
    'loadingAd': 'Loading Ad...',
    'pleaseWait': 'Please wait',
    'congratulations': 'Congratulations! 🎉',
    'earnedPoints': 'You earned 20 points!',
    'devMode': 'Developer Mode Activated! 🔧',
    'devModeDescription': 'Added 10000 points and 1000 UC!',
    // Menu items
    'aboutApp': 'ℹ️ About App',
    'privacyPolicy': '🔐 Privacy Policy',
    'termsOfUse': '📄 Terms of Use',
    // Notifications
    'welcomeNotificationTitle': 'Welcome to UC Craze! 🎮',
    'welcomeNotificationBody': 'Start your journey to earn free PUBG UC',
    'dailyReminderTitle': 'Don\'t forget your daily rewards! 🎁',
    'dailyReminderBody': 'Watch ads and earn points to withdraw UC'
  }
};

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState('ar');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'ar';
    setLanguageState(savedLanguage);
    document.documentElement.dir = savedLanguage === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = savedLanguage;
  }, []);

  const setLanguage = (lang: string) => {
    setLanguageState(lang);
    localStorage.setItem('language', lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const t = (key: string): string => {
    return translations[language as keyof typeof translations]?.[key as keyof typeof translations.ar] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
