
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import AdMobService from '../services/admobService';

export const useAdMob = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [dailyAdsWatched, setDailyAdsWatched] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    initializeAdMob();
    checkDailyLimit();
  }, []);

  const checkDailyLimit = () => {
    const today = new Date().toDateString();
    const lastAdDate = localStorage.getItem('lastAdDate');
    const dailyAdsCount = parseInt(localStorage.getItem('dailyAdsCount') || '0');

    if (lastAdDate !== today) {
      // Reset daily counter for new day
      localStorage.setItem('lastAdDate', today);
      localStorage.setItem('dailyAdsCount', '0');
      setDailyAdsWatched(0);
    } else {
      setDailyAdsWatched(dailyAdsCount);
    }
  };

  const initializeAdMob = async () => {
    try {
      const admobService = AdMobService.getInstance();
      await admobService.initialize();
      setIsInitialized(true);
      
      // تحضير الإعلان مسبقاً
      await admobService.prepareRewardedAd();
    } catch (error) {
      console.error('Failed to initialize AdMob:', error);
      toast({
        title: "خطأ في تهيئة الإعلانات",
        description: "حدث خطأ في تحضير الإعلانات",
        variant: "destructive"
      });
    }
  };

  const showRewardedAd = async (): Promise<boolean> => {
    if (isLoading) return false;

    // Check daily limit
    if (dailyAdsWatched >= 140) {
      toast({
        title: "تم الوصول للحد اليومي! 🚫",
        description: "لقد شاهدت 140 إعلان اليوم - عد غداً لمشاهدة المزيد! الحد اليومي: 140 إعلان. استمتع بالألعاب والأنشطة الأخرى! 💎",
        variant: "destructive",
        duration: 6000
      });
      return false;
    }

    setIsLoading(true);
    
    try {
      toast({
        title: "جاري تحميل الإعلان...",
        description: "الرجاء الانتظار"
      });

      const admobService = AdMobService.getInstance();
      const reward = await admobService.showRewardedAd();
      
      if (reward) {
        // Update daily counter
        const newDailyCount = dailyAdsWatched + 1;
        setDailyAdsWatched(newDailyCount);
        localStorage.setItem('dailyAdsCount', newDailyCount.toString());

        // Update total ads counter
        const totalAdsWatched = parseInt(localStorage.getItem('totalAdsWatched') || '0') + 1;
        localStorage.setItem('totalAdsWatched', totalAdsWatched.toString());

        // Add golden points when ad is watched
        const currentGoldenPoints = parseInt(localStorage.getItem('goldenPoints') || '0');
        const newGoldenPoints = currentGoldenPoints + 1;
        localStorage.setItem('goldenPoints', newGoldenPoints.toString());
        
        const remainingAds = 140 - newDailyCount;
        toast({
          title: "تم مشاهدة الإعلان! 🎉",
          description: `تم إضافة النقاط ونقطة ذهبية واحدة 🏅 (متبقي اليوم: ${remainingAds})`
        });
        
        // تحضير الإعلان التالي
        setTimeout(() => {
          admobService.prepareRewardedAd();
        }, 1000);
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error showing rewarded ad:', error);
      toast({
        title: "فشل في عرض الإعلان",
        description: "حدث خطأ أثناء تحميل الإعلان. حاول مرة أخرى",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    isInitialized,
    dailyAdsWatched,
    showRewardedAd
  };
};
