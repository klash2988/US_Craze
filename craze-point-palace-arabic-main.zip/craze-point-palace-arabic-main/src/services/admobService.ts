
import { AdMob, RewardAdOptions, RewardAdPluginEvents, AdMobRewardItem } from '@capacitor-community/admob';
import { ADMOB_CONFIG, getAdUnitId } from '../config/admob';

export class AdMobService {
  private static instance: AdMobService;
  private isInitialized = false;

  private constructor() {}

  static getInstance(): AdMobService {
    if (!AdMobService.instance) {
      AdMobService.instance = new AdMobService();
    }
    return AdMobService.instance;
  }

  // تهيئة AdMob
  async initialize(): Promise<void> {
    try {
      if (this.isInitialized) return;

      // التحقق من وجود Capacitor
      // @ts-ignore - Capacitor will be available in mobile app
      if (typeof window.Capacitor === 'undefined') {
        console.warn('AdMob: Capacitor not found, running in browser mode');
        return;
      }

      await AdMob.initialize({
        testingDevices: ADMOB_CONFIG.TEST_DEVICE_IDS,
        initializeForTesting: ADMOB_CONFIG.TEST_MODE,
      });

      this.isInitialized = true;
      console.log('AdMob initialized successfully');
    } catch (error) {
      console.error('Error initializing AdMob:', error);
      throw error;
    }
  }

  // عرض إعلان مكافأة
  async showRewardedAd(): Promise<AdMobRewardItem | null> {
    try {
      // التحقق من وجود Capacitor
      // @ts-ignore - Capacitor will be available in mobile app
      if (typeof window.Capacitor === 'undefined') {
        // محاكاة في المتصفح
        return new Promise((resolve) => {
          setTimeout(() => {
            resolve({ type: 'test', amount: 1 });
          }, 3000);
        });
      }

      if (!this.isInitialized) {
        await this.initialize();
      }

      const options: RewardAdOptions = {
        adId: getAdUnitId('REWARDED'),
        isTesting: ADMOB_CONFIG.TEST_MODE
      };

      return new Promise((resolve, reject) => {
        // الاستماع لأحداث الإعلان
        AdMob.addListener(RewardAdPluginEvents.Rewarded, (reward: AdMobRewardItem) => {
          console.log('User earned reward:', reward);
          resolve(reward);
        });

        AdMob.addListener(RewardAdPluginEvents.FailedToLoad, (error) => {
          console.error('Failed to load rewarded ad:', error);
          reject(error);
        });

        // تحضير وعرض الإعلان
        AdMob.prepareRewardVideoAd(options).then(() => {
          return AdMob.showRewardVideoAd();
        }).catch((error) => {
          console.error('Error showing rewarded ad:', error);
          reject(error);
        });
      });
    } catch (error) {
      console.error('Error in showRewardedAd:', error);
      throw error;
    }
  }

  // تحضير الإعلان مسبقاً
  async prepareRewardedAd(): Promise<void> {
    try {
      // @ts-ignore - Capacitor will be available in mobile app
      if (typeof window.Capacitor === 'undefined') {
        return;
      }

      if (!this.isInitialized) {
        await this.initialize();
      }

      const options: RewardAdOptions = {
        adId: getAdUnitId('REWARDED'),
        isTesting: ADMOB_CONFIG.TEST_MODE
      };

      await AdMob.prepareRewardVideoAd(options);
      console.log('Rewarded ad prepared successfully');
    } catch (error) {
      console.error('Error preparing rewarded ad:', error);
    }
  }
}

export default AdMobService;
