
import { useState, useEffect } from 'react';
import SplashScreen from '@/components/SplashScreen';
import HomeScreen from '@/components/HomeScreen';
import SettingsPage from '@/components/SettingsPage';
import UserStatsPage from '@/components/UserStatsPage';
import TasksCenter from '@/components/TasksCenter';
import WithdrawForm from '@/components/WithdrawForm';
import ThankYouPage from '@/components/ThankYouPage';
import ContentCreatorPage from '@/components/ContentCreatorPage';
import DeveloperMessagesPage from '@/components/DeveloperMessagesPage';
import UserRegistrationPage from '@/components/UserRegistrationPage';
import AboutAppPage from '@/components/AboutAppPage';
import PrivacyPolicyPage from '@/components/PrivacyPolicyPage';
import TermsPage from '@/components/TermsPage';
import SupportPage from '@/components/SupportPage';
import InviteFriendsPage from '@/components/InviteFriendsPage';
import AIChatPage from '@/components/AIChatPage';

const Index = () => {
  const [currentScreen, setCurrentScreen] = useState('splash');
  const [showWithdrawForm, setShowWithdrawForm] = useState(false);
  const [isUserRegistered, setIsUserRegistered] = useState(false);

  useEffect(() => {
    // Check if user is already registered
    const userName = localStorage.getItem('userName');
    const userId = localStorage.getItem('userId');
    
    if (userName && userId) {
      setIsUserRegistered(true);
    }

    const timer = setTimeout(() => {
      if (userName && userId) {
        setCurrentScreen('home');
      } else {
        setCurrentScreen('registration');
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const navigateToScreen = (screen: string) => {
    setCurrentScreen(screen);
  };

  const handleShowWithdrawForm = () => {
    setShowWithdrawForm(true);
  };

  const handleCloseWithdrawForm = () => {
    setShowWithdrawForm(false);
  };

  const handleUserRegistration = (userData: { name: string; userId: string }) => {
    setIsUserRegistered(true);
    setCurrentScreen('home');
  };

  if (currentScreen === 'splash') {
    return <SplashScreen />;
  }

  if (currentScreen === 'registration') {
    return <UserRegistrationPage onComplete={handleUserRegistration} />;
  }

  if (showWithdrawForm) {
    return (
      <WithdrawForm 
        onClose={handleCloseWithdrawForm}
        onSuccess={() => {
          setShowWithdrawForm(false);
          setCurrentScreen('thankYou');
        }}
      />
    );
  }

  switch (currentScreen) {
    case 'home':
      return (
        <HomeScreen 
          onNavigate={navigateToScreen}
          onShowWithdrawForm={handleShowWithdrawForm}
        />
      );
    case 'settings':
      return <SettingsPage onBack={() => navigateToScreen('home')} />;
    case 'userStats':
      return <UserStatsPage onBack={() => navigateToScreen('home')} />;
    case 'tasks':
      return <TasksCenter onBack={() => navigateToScreen('home')} />;
    case 'thankYou':
      return <ThankYouPage onNavigate={navigateToScreen} />;
    case 'contentCreator':
      return <ContentCreatorPage onBack={() => navigateToScreen('home')} />;
    case 'developerMessages':
      return <DeveloperMessagesPage onNavigate={navigateToScreen} />;
    case 'aboutApp':
      return <AboutAppPage onBack={() => navigateToScreen('home')} />;
    case 'privacyPolicy':
      return <PrivacyPolicyPage onBack={() => navigateToScreen('home')} />;
    case 'terms':
      return <TermsPage onBack={() => navigateToScreen('home')} />;
    case 'support':
      return <SupportPage onBack={() => navigateToScreen('home')} />;
    case 'inviteFriends':
      return <InviteFriendsPage onBack={() => navigateToScreen('home')} />;
    case 'aiChat':
      return <AIChatPage onBack={() => navigateToScreen('home')} />;
    default:
      return (
        <HomeScreen 
          onNavigate={navigateToScreen}
          onShowWithdrawForm={handleShowWithdrawForm}
        />
      );
  }
};

export default Index;
