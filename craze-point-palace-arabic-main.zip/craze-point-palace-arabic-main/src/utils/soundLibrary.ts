
// مكتبة الأصوات للتطبيق
export const soundLibrary = {
  // أصوات الانتقال
  pageTransition: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmESBjuW3+q3axkKAm4AAABgAEAAYAAAAAAAgACAAAAAAAEAAAEAAAAAAAAAAA=='),
  
  // أصوات النجاح
  success: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmESBjuW3+q3axkKAm4AAABgAEAAYAAAAAAAgACAAAAAAAEAAAEAAAAAAAAAAA=='),
  
  // أصوات الأزرار
  buttonClick: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmESBjuW3+q3axkKAm4AAABgAEAAYAAAAAAAgACAAAAAAAEAAAEAAAAAAAAAAA=='),
  
  // أصوات التحذير
  warning: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmESBjuW3+q3axkKAm4AAABgAEAAYAAAAAAAgACAAAAAAAEAAAEAAAAAAAAAAA=='),
  
  // أصوات الكسب
  pointsEarned: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmESBjuW3+q3axkKAm4AAABgAEAAYAAAAAAAgACAAAAAAAEAAAEAAAAAAAAAAA=='),
  
  // أصوات العجلة
  spinWheel: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmESBjuW3+q3axkKAm4AAABgAEAAYAAAAAAAgACAAAAAAAEAAAEAAAAAAAAAAA=='),
};

// إعدادات الصوت
export const setupSounds = () => {
  Object.values(soundLibrary).forEach(sound => {
    sound.volume = 0.3; // مستوى صوت معتدل
    sound.preload = 'auto';
  });
};
