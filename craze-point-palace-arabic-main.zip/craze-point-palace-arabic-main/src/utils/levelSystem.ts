
export interface UserLevel {
  level: number;
  title: string;
  minPoints: number;
  maxPoints: number;
  rank: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  color: string;
  benefits: string[];
}

export const LEVELS: UserLevel[] = [
  {
    level: 1,
    title: 'مبتدئ',
    minPoints: 0,
    maxPoints: 999,
    rank: 'bronze',
    color: '#CD7F32',
    benefits: ['مشاهدة الإعلانات', 'الدوران اليومي']
  },
  {
    level: 2,
    title: 'متدرب',
    minPoints: 1000,
    maxPoints: 2999,
    rank: 'bronze',
    color: '#CD7F32',
    benefits: ['مكافآت إضافية 5%', 'مهام يومية']
  },
  {
    level: 3,
    title: 'نشط',
    minPoints: 3000,
    maxPoints: 7999,
    rank: 'silver',
    color: '#C0C0C0',
    benefits: ['مكافآت إضافية 10%', 'دوران مميز مجاني أسبوعياً']
  },
  {
    level: 4,
    title: 'محترف',
    minPoints: 8000,
    maxPoints: 19999,
    rank: 'silver',
    color: '#C0C0C0',
    benefits: ['مكافآت إضافية 15%', 'أولوية في الدعم الفني']
  },
  {
    level: 5,
    title: 'خبير',
    minPoints: 20000,
    maxPoints: 49999,
    rank: 'gold',
    color: '#FFD700',
    benefits: ['مكافآت إضافية 20%', 'إعلانات أقل', 'مهام حصرية']
  },
  {
    level: 6,
    title: 'ماستر',
    minPoints: 50000,
    maxPoints: 99999,
    rank: 'platinum',
    color: '#E5E4E2',
    benefits: ['مكافآت إضافية 25%', 'نقاط مضاعفة يومياً', 'دعم مميز']
  },
  {
    level: 7,
    title: 'أسطورة',
    minPoints: 100000,
    maxPoints: 999999,
    rank: 'diamond',
    color: '#B9F2FF',
    benefits: ['مكافآت إضافية 30%', 'نقاط مضاعفة دائماً', 'مميزات حصرية']
  }
];

export const getUserLevel = (totalPoints: number): UserLevel => {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (totalPoints >= LEVELS[i].minPoints) {
      return LEVELS[i];
    }
  }
  return LEVELS[0];
};

export const getNextLevel = (currentLevel: UserLevel): UserLevel | null => {
  const currentIndex = LEVELS.findIndex(level => level.level === currentLevel.level);
  return currentIndex < LEVELS.length - 1 ? LEVELS[currentIndex + 1] : null;
};

export const getLevelProgress = (totalPoints: number): number => {
  const currentLevel = getUserLevel(totalPoints);
  const nextLevel = getNextLevel(currentLevel);
  
  if (!nextLevel) return 100;
  
  const pointsInCurrentLevel = totalPoints - currentLevel.minPoints;
  const pointsNeededForNext = nextLevel.minPoints - currentLevel.minPoints;
  
  return Math.round((pointsInCurrentLevel / pointsNeededForNext) * 100);
};
