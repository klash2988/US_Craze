
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface PrivacyPolicyPageProps {
  onBack: () => void;
}

const PrivacyPolicyPage = ({ onBack }: PrivacyPolicyPageProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-yellow-400 to-orange-500 p-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-white">🔐 سياسة الخصوصية</h1>
      </div>

      {/* Content */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mx-auto max-w-md shadow-lg">
        <div className="text-center space-y-4 text-gray-800 leading-relaxed">
          <p className="text-lg font-semibold text-green-600">
            🛡️ نحن نحترم خصوصيتك.
          </p>
          <p>
            لا نقوم بجمع أي بيانات شخصية بدون إذنك.
          </p>
          <p>
            جميع البيانات محفوظة محليًا على جهازك.
          </p>
          <p>
            يمكنك التواصل معنا عبر البريد التالي:
          </p>
          <p className="text-blue-600 font-mono">
            📧 klash29885@gmail.com
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;
