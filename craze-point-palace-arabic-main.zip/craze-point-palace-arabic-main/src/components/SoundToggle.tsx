
import { Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSounds } from '@/hooks/useSounds';

const SoundToggle = () => {
  const { isEnabled, toggleSounds } = useSounds();

  return (
    <Button
      variant="ghost"
      onClick={toggleSounds}
      className="flex items-center gap-2 w-full justify-start"
    >
      {isEnabled ? (
        <Volume2 className="w-5 h-5" />
      ) : (
        <VolumeX className="w-5 h-5" />
      )}
      <span>{isEnabled ? 'إيقاف الأصوات' : 'تشغيل الأصوات'}</span>
    </Button>
  );
};

export default SoundToggle;
