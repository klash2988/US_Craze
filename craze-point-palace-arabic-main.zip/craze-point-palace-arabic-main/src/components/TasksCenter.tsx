import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { ArrowRight, Youtube, MessageCircle, CheckCircle, Trophy, Play, Users, Crown, Gift, Star, Target, Calendar } from 'lucide-react';

interface TasksCenterProps {
  onBack: () => void;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  target: number;
  reward: number;
  rewardType: 'points' | 'uc';
  icon: React.ReactNode;
  type: 'ads' | 'bigAds' | 'referrals' | 'points' | 'daily' | 'special';
  completed: boolean;
  current: number;
  claimed: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

const TasksCenter = ({ onBack }: TasksCenterProps) => {
  const [youtubeAttempts, setYoutubeAttempts] = useState(0);
  const [telegramAttempts, setTelegramAttempts] = useState(0);
  const [youtubeCompleted, setYoutubeCompleted] = useState(false);
  const [telegramCompleted, setTelegramCompleted] = useState(false);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [pendingRewards, setPendingRewards] = useState({ points: 0, uc: 0 });
  const [filter, setFilter] = useState<string>('all');
  const { toast } = useToast();

  useEffect(() => {
    const ytCompleted = localStorage.getItem('youtubeTaskCompleted') === 'true';
    const tgCompleted = localStorage.getItem('telegramTaskCompleted') === 'true';
    const ytAttempts = parseInt(localStorage.getItem('youtubeAttempts') || '0');
    const tgAttempts = parseInt(localStorage.getItem('telegramAttempts') || '0');
    
    setYoutubeCompleted(ytCompleted);
    setTelegramCompleted(tgCompleted);
    setYoutubeAttempts(ytAttempts);
    setTelegramAttempts(tgAttempts);
    
    loadAchievements();
    calculatePendingRewards();
  }, []);

  const loadAchievements = () => {
    const adsWatched = parseInt(localStorage.getItem('totalAdsWatched') || '0');
    const totalPoints = parseInt(localStorage.getItem('pointsBalance') || '0') + 
                       parseInt(localStorage.getItem('totalPointsEarned') || '0');
    const totalReferrals = parseInt(localStorage.getItem('totalReferrals') || '0');
    const validReferrals = Math.min(totalReferrals, Math.floor(adsWatched / 51));
    const daysActive = Math.floor((Date.now() - Date.parse(localStorage.getItem('joinDate') || new Date().toISOString())) / (1000 * 60 * 60 * 24)) + 1;
    
    const claimedAchievements = JSON.parse(localStorage.getItem('claimedAchievements') || '[]');

    const achievementsList: Achievement[] = [
      // إنجازات الإعلانات الأساسية
      {
        id: 'ads299',
        title: 'مشاهد الإعلانات المبتدئ',
        description: 'شاهد 299 إعلان',
        target: 299,
        reward: 400,
        rewardType: 'points',
        icon: <Play className="w-8 h-8 text-green-500" />,
        type: 'ads',
        completed: adsWatched >= 299,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads299'),
        rarity: 'common'
      },
      {
        id: 'ads1000',
        title: 'ملك الإعلانات',
        description: 'شاهد 1000 إعلان',
        target: 1000,
        reward: 2000,
        rewardType: 'points',
        icon: <Trophy className="w-8 h-8 text-gold-500" />,
        type: 'bigAds',
        completed: adsWatched >= 1000,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads1000'),
        rarity: 'epic'
      },
      
      // إنجازات الإعلانات المتقدمة
      {
        id: 'first_ad',
        title: 'البداية',
        description: 'شاهد أول إعلان',
        target: 1,
        reward: 50,
        rewardType: 'points',
        icon: <Target className="w-6 h-6" />,
        type: 'ads',
        completed: adsWatched >= 1,
        current: adsWatched,
        claimed: claimedAchievements.includes('first_ad'),
        rarity: 'common'
      },
      {
        id: 'ads_10',
        title: 'متابع نشط',
        description: 'شاهد 10 إعلانات',
        target: 10,
        reward: 200,
        rewardType: 'points',
        icon: <Target className="w-6 h-6" />,
        type: 'ads',
        completed: adsWatched >= 10,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads_10'),
        rarity: 'common'
      },
      {
        id: 'ads_50',
        title: 'عاشق الإعلانات',
        description: 'شاهد 50 إعلان',
        target: 50,
        reward: 500,
        rewardType: 'points',
        icon: <Target className="w-6 h-6" />,
        type: 'ads',
        completed: adsWatched >= 50,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads_50'),
        rarity: 'rare'
      },
      {
        id: 'ads_100',
        title: 'ماستر الإعلانات',
        description: 'شاهد 100 إعلان',
        target: 100,
        reward: 1000,
        rewardType: 'points',
        icon: <Crown className="w-6 h-6" />,
        type: 'ads',
        completed: adsWatched >= 100,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads_100'),
        rarity: 'epic'
      },
      {
        id: 'ads_500',
        title: 'أسطورة الإعلانات',
        description: 'شاهد 500 إعلان',
        target: 500,
        reward: 5000,
        rewardType: 'points',
        icon: <Crown className="w-6 h-6" />,
        type: 'ads',
        completed: adsWatched >= 500,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads_500'),
        rarity: 'legendary'
      },
      
      // إنجازات النقاط
      {
        id: 'points_1000',
        title: 'جامع النقاط',
        description: 'اجمع 1000 نقطة',
        target: 1000,
        reward: 100,
        rewardType: 'points',
        icon: <Star className="w-6 h-6" />,
        type: 'points',
        completed: totalPoints >= 1000,
        current: totalPoints,
        claimed: claimedAchievements.includes('points_1000'),
        rarity: 'common'
      },
      {
        id: 'points_10000',
        title: 'ثري النقاط',
        description: 'اجمع 10,000 نقطة',
        target: 10000,
        reward: 1000,
        rewardType: 'points',
        icon: <Star className="w-6 h-6" />,
        type: 'points',
        completed: totalPoints >= 10000,
        current: totalPoints,
        claimed: claimedAchievements.includes('points_10000'),
        rarity: 'rare'
      },
      {
        id: 'points_50000',
        title: 'ملك النقاط',
        description: 'اجمع 50,000 نقطة',
        target: 50000,
        reward: 5000,
        rewardType: 'points',
        icon: <Crown className="w-6 h-6" />,
        type: 'points',
        completed: totalPoints >= 50000,
        current: totalPoints,
        claimed: claimedAchievements.includes('points_50000'),
        rarity: 'epic'
      },
      
      // إنجازات الإحالة
      {
        id: 'referrals5',
        title: 'داعي الأصدقاء',
        description: 'ادع 5 أصدقاء',
        target: 5,
        reward: 1000,
        rewardType: 'points',
        icon: <Users className="w-8 h-8 text-blue-500" />,
        type: 'referrals',
        completed: validReferrals >= 5,
        current: validReferrals,
        claimed: claimedAchievements.includes('referrals5'),
        rarity: 'common'
      },
      {
        id: 'referrals20',
        title: 'محترف الدعوات',
        description: 'ادع 20 صديق',
        target: 20,
        reward: 30,
        rewardType: 'uc',
        icon: <Users className="w-8 h-8 text-purple-500" />,
        type: 'referrals',
        completed: validReferrals >= 20,
        current: validReferrals,
        claimed: claimedAchievements.includes('referrals20'),
        rarity: 'rare'
      },
      {
        id: 'referrals140',
        title: 'ملك الدعوات',
        description: 'ادع 140 شخص',
        target: 140,
        reward: 325,
        rewardType: 'uc',
        icon: <Trophy className="w-8 h-8 text-orange-500" />,
        type: 'referrals',
        completed: validReferrals >= 140,
        current: validReferrals,
        claimed: claimedAchievements.includes('referrals140'),
        rarity: 'legendary'
      },
      {
        id: 'referral_1',
        title: 'أول صديق',
        description: 'ادع صديقاً واحداً',
        target: 1,
        reward: 300,
        rewardType: 'points',
        icon: <Users className="w-6 h-6" />,
        type: 'referrals',
        completed: validReferrals >= 1,
        current: validReferrals,
        claimed: claimedAchievements.includes('referral_1'),
        rarity: 'common'
      },
      {
        id: 'referral_10',
        title: 'سفير التطبيق',
        description: 'ادع 10 أصدقاء',
        target: 10,
        reward: 3000,
        rewardType: 'points',
        icon: <Crown className="w-6 h-6" />,
        type: 'referrals',
        completed: validReferrals >= 10,
        current: validReferrals,
        claimed: claimedAchievements.includes('referral_10'),
        rarity: 'epic'
      },
      
      // إنجازات يومية
      {
        id: 'daily_7',
        title: 'مستخدم أسبوعي',
        description: 'استخدم التطبيق لمدة 7 أيام',
        target: 7,
        reward: 500,
        rewardType: 'points',
        icon: <Calendar className="w-6 h-6" />,
        type: 'daily',
        completed: daysActive >= 7,
        current: daysActive,
        claimed: claimedAchievements.includes('daily_7'),
        rarity: 'common'
      },
      {
        id: 'daily_30',
        title: 'مستخدم شهري',
        description: 'استخدم التطبيق لمدة 30 يوم',
        target: 30,
        reward: 2000,
        rewardType: 'points',
        icon: <Calendar className="w-6 h-6" />,
        type: 'daily',
        completed: daysActive >= 30,
        current: daysActive,
        claimed: claimedAchievements.includes('daily_30'),
        rarity: 'rare'
      },
      {
        id: 'daily_100',
        title: 'مستخدم مخضرم',
        description: 'استخدم التطبيق لمدة 100 يوم',
        target: 100,
        reward: 10000,
        rewardType: 'points',
        icon: <Crown className="w-6 h-6" />,
        type: 'daily',
        completed: daysActive >= 100,
        current: daysActive,
        claimed: claimedAchievements.includes('daily_100'),
        rarity: 'legendary'
      }
    ];

    setAchievements(achievementsList);
  };

  const calculatePendingRewards = () => {
    const pendingAchievementRewards = JSON.parse(localStorage.getItem('pendingAchievementRewards') || '{"points": 0, "uc": 0}');
    setPendingRewards(pendingAchievementRewards);
  };

  const claimReward = (achievement: Achievement) => {
    if (achievement.claimed) {
      toast({
        title: "تم استلام المكافأة مسبقاً",
        description: "لقد حصلت على هذه المكافأة من قبل",
        variant: "destructive"
      });
      return;
    }

    if (!achievement.completed) {
      toast({
        title: "الإنجاز غير مكتمل",
        description: "أكمل الإنجاز أولاً للحصول على المكافأة",
        variant: "destructive"
      });
      return;
    }

    const currentPending = JSON.parse(localStorage.getItem('pendingAchievementRewards') || '{"points": 0, "uc": 0}');
    if (achievement.rewardType === 'points') {
      currentPending.points += achievement.reward;
    } else {
      currentPending.uc += achievement.reward;
    }
    localStorage.setItem('pendingAchievementRewards', JSON.stringify(currentPending));
    
    const claimedAchievements = JSON.parse(localStorage.getItem('claimedAchievements') || '[]');
    claimedAchievements.push(achievement.id);
    localStorage.setItem('claimedAchievements', JSON.stringify(claimedAchievements));

    setAchievements(prev => prev.map(ach => 
      ach.id === achievement.id ? { ...ach, claimed: true } : ach
    ));

    setPendingRewards(currentPending);

    const rewardText = achievement.rewardType === 'points' ? 'نقطة' : 'شدة';
    toast({
      title: "تم طلب المكافأة! 🎁",
      description: `تم إضافة ${achievement.reward} ${rewardText} للمكافآت المعلقة!`
    });
  };

  const collectAllRewards = () => {
    if (pendingRewards.points === 0 && pendingRewards.uc === 0) {
      toast({
        title: "لا توجد مكافآت معلقة",
        description: "اطلب مكافآت الإنجازات أولاً",
        variant: "destructive"
      });
      return;
    }

    if (pendingRewards.points > 0) {
      const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
      const newPoints = currentPoints + pendingRewards.points;
      localStorage.setItem('pointsBalance', newPoints.toString());
    }

    if (pendingRewards.uc > 0) {
      const currentUC = parseInt(localStorage.getItem('totalUCWon') || '0');
      const newUC = currentUC + pendingRewards.uc;
      localStorage.setItem('totalUCWon', newUC.toString());
    }

    localStorage.setItem('pendingAchievementRewards', '{"points": 0, "uc": 0}');
    setPendingRewards({ points: 0, uc: 0 });

    toast({
      title: "تم تجميع جميع المكافآت! 🎉",
      description: `تم إضافة ${pendingRewards.points} نقطة و ${pendingRewards.uc} شدة إلى رصيدك!`
    });
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const handleYoutubeTask = () => {
    window.open('https://youtube.com/@user-hk-bobo', '_blank');
    
    setTimeout(() => {
      const newAttempts = youtubeAttempts + 1;
      setYoutubeAttempts(newAttempts);
      localStorage.setItem('youtubeAttempts', newAttempts.toString());

      if (newAttempts < 3) {
        toast({
          title: "فشل التحقق ❌",
          description: `المحاولة ${newAttempts}/3. حاول مرة أخرى.`,
          variant: "destructive"
        });
      } else {
        setYoutubeCompleted(true);
        localStorage.setItem('youtubeTaskCompleted', 'true');
        
        const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
        const newPoints = currentPoints + 300;
        localStorage.setItem('pointsBalance', newPoints.toString());

        toast({
          title: "تم التحقق! ✅",
          description: "تم إضافة 300 نقطة إلى رصيدك!"
        });
      }
    }, 3000);
  };

  const handleTelegramTask = () => {
    window.open('https://t.me/USCRAZE', '_blank');
    
    setTimeout(() => {
      const newAttempts = telegramAttempts + 1;
      setTelegramAttempts(newAttempts);
      localStorage.setItem('telegramAttempts', newAttempts.toString());

      if (newAttempts < 3) {
        toast({
          title: "فشل التحقق ❌",
          description: `المحاولة ${newAttempts}/3. حاول مرة أخرى.`,
          variant: "destructive"
        });
      } else {
        setTelegramCompleted(true);
        localStorage.setItem('telegramTaskCompleted', 'true');
        
        const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
        const newPoints = currentPoints + 300;
        localStorage.setItem('pointsBalance', newPoints.toString());

        toast({
          title: "تم التحقق! ✅",
          description: "تم إضافة 300 نقطة إلى رصيدك!"
        });
      }
    }, 3000);
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'from-gray-500 to-gray-600';
      case 'rare': return 'from-blue-500 to-blue-600';
      case 'epic': return 'from-purple-500 to-purple-600';
      case 'legendary': return 'from-yellow-500 to-orange-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const filteredAchievements = filter === 'all' 
    ? achievements 
    : achievements.filter(a => a.type === filter);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 p-4" dir="rtl">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={onBack} className="text-white">
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white mr-4">مركز المهام والإنجازات 🏆</h1>
        </div>

        {/* Filter Buttons */}
        <div className="flex gap-2 mb-4 overflow-x-auto">
          {[
            { key: 'all', label: 'الكل' },
            { key: 'ads', label: 'إعلانات' },
            { key: 'points', label: 'نقاط' },
            { key: 'referrals', label: 'إحالات' },
            { key: 'daily', label: 'يومية' },
            { key: 'special', label: 'خاصة' }
          ].map((category) => (
            <Button
              key={category.key}
              variant={filter === category.key ? "default" : "ghost"}
              size="sm"
              onClick={() => setFilter(category.key)}
              className={`whitespace-nowrap ${filter === category.key ? 'bg-white text-black' : 'text-white hover:bg-white/20'}`}
            >
              {category.label}
            </Button>
          ))}
        </div>

        {/* Pending Rewards Section */}
        {(pendingRewards.points > 0 || pendingRewards.uc > 0) && (
          <div className="bg-yellow-500/20 backdrop-blur-sm rounded-lg p-4 mb-6 border border-yellow-400/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Gift className="w-6 h-6 text-yellow-300" />
                <h3 className="font-bold text-white">المكافآت المعلقة</h3>
              </div>
            </div>
            <div className="flex justify-between items-center mb-4">
              <div className="text-white">
                {pendingRewards.points > 0 && <span>{pendingRewards.points} نقطة</span>}
                {pendingRewards.points > 0 && pendingRewards.uc > 0 && <span> • </span>}
                {pendingRewards.uc > 0 && <span>{pendingRewards.uc} شدة</span>}
              </div>
            </div>
            <Button
              onClick={collectAllRewards}
              className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
            >
              تجميع جميع المكافآت 🎁
            </Button>
          </div>
        )}

        <div className="space-y-4">
          {/* Tasks Section */}
          {(filter === 'all' || filter === 'special') && (
            <>
              {/* YouTube Task */}
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Youtube className="w-8 h-8 text-red-500" />
                    <div>
                      <h3 className="font-bold text-white">زيارة قناة اليوتيوب</h3>
                      <p className="text-sm text-white/80">اشترك في القناة واحصل على 300 نقطة</p>
                    </div>
                  </div>
                  {youtubeCompleted && <CheckCircle className="w-6 h-6 text-green-400" />}
                </div>

                <div className="mb-4">
                  <div className="bg-white/20 rounded p-3">
                    <p className="text-white text-sm">@user-hk-bobo</p>
                  </div>
                </div>

                <Button
                  onClick={handleYoutubeTask}
                  disabled={youtubeCompleted}
                  className="w-full bg-red-600 hover:bg-red-700 text-white"
                >
                  {youtubeCompleted ? 'مكتملة ✅' : `زيارة القناة (${youtubeAttempts}/3)`}
                </Button>
              </div>

              {/* Telegram Task */}
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <MessageCircle className="w-8 h-8 text-blue-500" />
                    <div>
                      <h3 className="font-bold text-white">انضم لتيليجرام</h3>
                      <p className="text-sm text-white/80">انضم للقناة واحصل على 300 نقطة</p>
                    </div>
                  </div>
                  {telegramCompleted && <CheckCircle className="w-6 h-6 text-green-400" />}
                </div>

                <div className="mb-4">
                  <div className="bg-white/20 rounded p-3">
                    <p className="text-white text-sm">@USCRAZE</p>
                  </div>
                </div>

                <Button
                  onClick={handleTelegramTask}
                  disabled={telegramCompleted}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {telegramCompleted ? 'مكتملة ✅' : `انضم للقناة (${telegramAttempts}/3)`}
                </Button>
              </div>
            </>
          )}

          {/* Achievements Section */}
          <div className="space-y-4">
            {filteredAchievements.map((achievement) => {
              const progress = Math.min((achievement.current / achievement.target) * 100, 100);
              
              return (
                <div
                  key={achievement.id}
                  className={`bg-gradient-to-r ${getRarityColor(achievement.rarity)} rounded-xl p-4 border border-white/20 ${achievement.completed ? 'shadow-lg' : 'opacity-70'}`}
                >
                  <div className="flex items-start gap-4">
                    <div className="text-white">
                      {achievement.icon}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="text-white font-bold text-lg">{achievement.title}</h3>
                          <p className="text-white/80 text-sm">{achievement.description}</p>
                        </div>
                        <div className="text-right">
                          <div className="bg-white/20 rounded-full px-3 py-1">
                            <span className="text-white text-sm font-bold">
                              +{achievement.reward} {achievement.rewardType === 'points' ? 'نقطة' : 'شدة'}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-white text-sm">
                          <span>التقدم</span>
                          <span>{achievement.current}/{achievement.target}</span>
                        </div>
                        <Progress value={progress} className="h-2 bg-white/20" />
                      </div>
                      
                      {achievement.completed && (
                        <div className="mt-3">
                          {achievement.claimed ? (
                            <div className="bg-green-500/20 text-green-300 px-4 py-2 rounded-lg text-center">
                              ✓ تم استلام المكافأة
                            </div>
                          ) : (
                            <Button
                              onClick={() => claimReward(achievement)}
                              className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold"
                            >
                              <Gift className="w-4 h-4 mr-2" />
                              استلم المكافأة
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Info */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <h3 className="font-bold text-white mb-2">ملاحظات مهمة:</h3>
            <ul className="text-sm text-white/90 space-y-1">
              <li>• يتم التحقق تلقائياً بعد زيارة الرابط</li>
              <li>• المحاولتان الأولى والثانية ستفشلان</li>
              <li>• المحاولة الثالثة ستنجح وتحصل على النقاط</li>
              <li>• كل مهمة تعطي 300 نقطة</li>
              <li className="text-yellow-300 font-bold">• لا تحسب الدعوة إلا عند مشاهدة المستخدم 51 إعلان بحد أدنى</li>
              <li className="text-green-300 font-bold">• نقاط الإعلانات تُضاف تلقائياً، مكافآت الإنجازات تُجمع يدوياً</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TasksCenter;
