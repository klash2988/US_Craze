
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  ArrowRight, 
  MessageCircle, 
  Phone, 
  Mail, 
  Bot, 
  HelpCircle, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Star,
  Send,
  Copy,
  ExternalLink
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/hooks/useLanguage';

interface SupportPageProps {
  onBack: () => void;
}

const SupportPage = ({ onBack }: SupportPageProps) => {
  const [selectedTopic, setSelectedTopic] = useState('');
  const [message, setMessage] = useState('');
  const [selectedContactMethod, setSelectedContactMethod] = useState('');
  const { toast } = useToast();
  const { language } = useLanguage();

  const supportTopics = [
    {
      id: 'withdraw',
      title: 'مشاكل السحب',
      icon: <AlertCircle className="w-5 h-5" />,
      color: 'from-red-500 to-red-600',
      description: 'مساعدة في عمليات سحب الشدات'
    },
    {
      id: 'ads',
      title: 'مشاكل الإعلانات',
      icon: <Bot className="w-5 h-5" />,
      color: 'from-blue-500 to-blue-600',
      description: 'حل مشاكل عرض الإعلانات'
    },
    {
      id: 'account',
      title: 'مشاكل الحساب',
      icon: <HelpCircle className="w-5 h-5" />,
      color: 'from-green-500 to-green-600',
      description: 'إدارة بيانات الحساب'
    },
    {
      id: 'points',
      title: 'مشاكل النقاط',
      icon: <Star className="w-5 h-5" />,
      color: 'from-yellow-500 to-yellow-600',
      description: 'استفسارات حول النقاط والمكافآت'
    }
  ];

  const contactMethods = [
    {
      id: 'telegram',
      title: 'تلجرام',
      icon: '📱',
      description: 'تواصل فوري',
      username: '@moon_2_0_2_4',
      action: () => window.open('https://t.me/moon_2_0_2_4', '_blank')
    },
    {
      id: 'email',
      title: 'البريد الإلكتروني',
      icon: '📧',
      description: 'رسالة مفصلة',
      address: 'klash29885@gmail.com',
      action: () => handleSendEmail()
    }
  ];

  const faqItems = [
    {
      question: 'كم يحتاج وقت لمعالجة طلب السحب؟',
      answer: 'عادة يتم معالجة طلبات السحب خلال 24-48 ساعة في أيام العمل.'
    },
    {
      question: 'لماذا لا تظهر الإعلانات؟',
      answer: 'تأكد من اتصالك بالإنترنت وأنك لم تتجاوز الحد اليومي 140 إعلان.'
    },
    {
      question: 'كيف أحصل على نقاط إضافية؟',
      answer: 'يمكنك الحصول على نقاط من خلال مشاهدة الإعلانات، إكمال المهام، والدوران اليومي.'
    },
    {
      question: 'هل يمكنني تغيير معرف المستخدم؟',
      answer: 'لا يمكن تغيير معرف المستخدم بعد إنشاء الحساب لأسباب أمنية.'
    }
  ];

  const handleSendEmail = () => {
    if (!selectedTopic || !message.trim()) {
      toast({
        title: "معلومات ناقصة",
        description: "يرجى اختيار موضوع وكتابة رسالة",
        variant: "destructive"
      });
      return;
    }

    const userCode = localStorage.getItem('userCode') || localStorage.getItem('userId') || '';
    const subject = encodeURIComponent(`دعم فني - ${supportTopics.find(t => t.id === selectedTopic)?.title}`);
    const body = encodeURIComponent(`كود المستخدم: ${userCode}\n\nالموضوع: ${supportTopics.find(t => t.id === selectedTopic)?.title}\n\nالرسالة:\n${message}`);
    
    window.open(`mailto:klash29885@gmail.com?subject=${subject}&body=${body}`);
    
    toast({
      title: "تم إرسال الرسالة! 📧",
      description: "سيتم الرد عليك في أقرب وقت ممكن"
    });
  };

  const handleSendMessage = () => {
    if (!selectedContactMethod) {
      toast({
        title: "اختر طريقة التواصل",
        description: "يرجى اختيار تلجرام أو البريد الإلكتروني",
        variant: "destructive"
      });
      return;
    }

    const method = contactMethods.find(m => m.id === selectedContactMethod);
    if (method) {
      method.action();
    }
  };

  const copyContact = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "تم النسخ! 📋",
      description: `تم نسخ ${type}`
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20 transform hover:scale-110 transition-all duration-300"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <div className="text-center flex-1">
          <h1 className="text-3xl font-bold text-white mb-2">🎧 مركز الدعم الفني</h1>
          <p className="text-white/80 text-sm">نحن هنا لمساعدتك 24/7</p>
        </div>
      </div>

      {/* Quick Contact Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
          <CardContent className="p-4 text-center">
            <div className="bg-green-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold mb-1">دردشة مباشرة</h3>
            <p className="text-white/70 text-xs">متاح الآن</p>
            <div className="flex items-center justify-center gap-1 mt-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-xs">أونلاين</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
          <CardContent className="p-4 text-center">
            <div className="bg-blue-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold mb-1">البريد الإلكتروني</h3>
            <p className="text-white/70 text-xs">klash29885@gmail.com</p>
            <Button
              onClick={() => copyContact('klash29885@gmail.com', 'البريد الإلكتروني')}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 mt-2 h-6 text-xs"
            >
              <Copy className="w-3 h-3 ml-1" />
              نسخ
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
          <CardContent className="p-4 text-center">
            <div className="bg-orange-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold mb-1">وقت الاستجابة</h3>
            <p className="text-white/70 text-xs">خلال 2-4 ساعات</p>
            <div className="text-orange-400 text-xs mt-2">⚡ سريع</div>
          </CardContent>
        </Card>
      </div>

      {/* Contact Methods Selection */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-center">اختر طريقة التواصل</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {contactMethods.map((method) => (
              <Button
                key={method.id}
                onClick={() => setSelectedContactMethod(method.id)}
                className={`h-24 flex flex-col items-center justify-center gap-2 transition-all duration-300 transform hover:scale-105 relative overflow-hidden ${
                  selectedContactMethod === method.id
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg scale-105'
                    : 'bg-white/20 hover:bg-white/30 text-white'
                }`}
              >
                {selectedContactMethod === method.id && (
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-transparent to-purple-400/20 animate-pulse"></div>
                )}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="text-3xl mb-2">{method.icon}</div>
                  <span className="font-bold text-sm">{method.title}</span>
                  <span className="text-xs opacity-90">{method.description}</span>
                  {method.username && (
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-xs font-mono">{method.username}</span>
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          copyContact(method.username!, 'معرف التلجرام');
                        }}
                        variant="ghost"
                        size="sm"
                        className="h-4 w-4 p-0 text-white hover:bg-white/20"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                  {selectedContactMethod === method.id && (
                    <CheckCircle className="w-4 h-4 text-white animate-pulse mt-1" />
                  )}
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Support Topics */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-center">اختر موضوع المساعدة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {supportTopics.map((topic) => (
              <Button
                key={topic.id}
                onClick={() => setSelectedTopic(topic.id)}
                className={`h-20 flex flex-col items-center justify-center gap-2 transition-all duration-300 transform hover:scale-105 ${
                  selectedTopic === topic.id
                    ? `bg-gradient-to-r ${topic.color} text-white shadow-lg scale-105`
                    : 'bg-white/20 hover:bg-white/30 text-white'
                }`}
              >
                <div className={`rounded-full w-8 h-8 flex items-center justify-center ${
                  selectedTopic === topic.id ? 'bg-white/20' : 'bg-white/10'
                }`}>
                  {topic.icon}
                </div>
                <span className="font-bold text-xs text-center">{topic.title}</span>
                {selectedTopic === topic.id && (
                  <CheckCircle className="w-4 h-4 text-white animate-pulse" />
                )}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Message Form */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-center">اكتب رسالتك</CardTitle>
        </CardHeader>
        <CardContent>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="اشرح مشكلتك بالتفصيل..."
            className="w-full h-32 p-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 resize-none focus:outline-none focus:ring-2 focus:ring-white/30"
          />
          <Button
            onClick={handleSendMessage}
            className="w-full mt-4 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-3 rounded-xl transform hover:scale-105 transition-all duration-300"
          >
            <Send className="w-5 h-5 ml-2" />
            إرسال الرسالة
            <ExternalLink className="w-4 h-4 mr-2" />
          </Button>
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white text-center">الأسئلة الشائعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {faqItems.map((item, index) => (
              <div key={index} className="bg-white/10 rounded-xl p-4 border border-white/20">
                <div className="flex items-center gap-3 mb-2">
                  <div className="bg-purple-500 rounded-full w-6 h-6 flex items-center justify-center">
                    <HelpCircle className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="text-white font-bold text-sm">{item.question}</h3>
                </div>
                <p className="text-white/80 text-xs mr-9">{item.answer}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SupportPage;
