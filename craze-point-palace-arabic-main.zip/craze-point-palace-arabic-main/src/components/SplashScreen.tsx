
import { useEffect } from 'react';

interface SplashScreenProps {
  onComplete?: () => void;
}

const SplashScreen = ({ onComplete }: SplashScreenProps) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      if (onComplete) {
        onComplete();
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center overflow-hidden">
      <div className="animate-fade-in">
        <img 
          src="/lovable-uploads/c2c6d326-241b-45a8-9109-9d19d361e5e6.png" 
          alt="UC Craze Logo" 
          className="w-80 h-80 object-contain animate-pulse"
        />
      </div>
    </div>
  );
};

export default SplashScreen;
