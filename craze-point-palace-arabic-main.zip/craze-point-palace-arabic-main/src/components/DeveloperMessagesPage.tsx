import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Lock, 
  Shield, 
  MessageCircle, 
  Send, 
  Bell,
  Users,
  Eye,
  CheckCircle,
  AlertCircle,
  Star,
  Code,
  Crown,
  User,
  Check
} from 'lucide-react';

interface DeveloperMessagesPageProps {
  onNavigate: (screen: string) => void;
}

interface Message {
  id: string;
  title: string;
  content: string;
  type: 'announcement' | 'update' | 'warning' | 'info';
  timestamp: Date;
  isRead: boolean;
  recipientType: 'all' | 'specific';
  targetUserCode?: string;
}

interface AdminRequest {
  id: string;
  type: 'withdraw' | 'content';
  userCode: string;
  details: any;
  timestamp: Date;
  status: 'pending' | 'handled';
}

const DeveloperMessagesPage = ({ onNavigate }: DeveloperMessagesPageProps) => {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [userMessages, setUserMessages] = useState<Message[]>([]);
  const [adminRequests, setAdminRequests] = useState<AdminRequest[]>([]);
  const [newMessage, setNewMessage] = useState({ 
    title: '', 
    content: '', 
    type: 'info' as const,
    recipientType: 'all' as 'all' | 'specific',
    targetUserCode: ''
  });
  const { toast } = useToast();

  const userCode = localStorage.getItem('userCode') || '';
  const ADMIN_PASSWORD = 'Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@Qpwo1234@';

  useEffect(() => {
    // Load user messages
    const savedMessages = localStorage.getItem('userMessages');
    if (savedMessages) {
      const parsed = JSON.parse(savedMessages);
      setUserMessages(parsed.map((msg: any) => ({
        ...msg,
        timestamp: new Date(msg.timestamp),
        recipientType: msg.recipientType || 'all',
        targetUserCode: msg.targetUserCode || ''
      })));
    } else {
      // Default welcome messages
      const defaultMessages: Message[] = [
        {
          id: '1',
          title: '🎉 مرحباً بك في UC Craze',
          content: 'مرحباً بك في تطبيق UC Craze! نحن سعداء لانضمامك إلينا. استمتع بجمع النقاط والفوز بالشدات مجاناً!',
          type: 'announcement',
          timestamp: new Date(),
          isRead: false,
          recipientType: 'all'
        },
        {
          id: '2',
          title: '📢 تحديث جديد v1.0',
          content: 'تم إضافة ميزات جديدة رائعة! الآن يمكنك دعوة الأصدقاء والحصول على مكافآت إضافية.',
          type: 'update',
          timestamp: new Date(Date.now() - 86400000),
          isRead: false,
          recipientType: 'all'
        }
      ];
      setUserMessages(defaultMessages);
      localStorage.setItem('userMessages', JSON.stringify(defaultMessages));
    }

    // Load admin requests (withdraw/content requests)
    loadAdminRequests();
  }, []);

  const loadAdminRequests = () => {
    const requests: AdminRequest[] = [];
    
    // Load withdraw requests
    const withdrawRequests = JSON.parse(localStorage.getItem('withdrawRequests') || '[]');
    withdrawRequests.forEach((req: any) => {
      requests.push({
        id: req.id,
        type: 'withdraw',
        userCode: req.userCode,
        details: req,
        timestamp: new Date(req.timestamp),
        status: 'pending'
      });
    });

    // Load content requests
    const contentRequests = JSON.parse(localStorage.getItem('contentRequests') || '[]');
    contentRequests.forEach((req: any) => {
      requests.push({
        id: req.id,
        type: 'content',
        userCode: req.channelId,
        details: req,
        timestamp: new Date(req.timestamp),
        status: 'pending'
      });
    });

    setAdminRequests(requests);
  };

  const handleAdminLogin = () => {
    if (adminPassword === ADMIN_PASSWORD) {
      setIsAdminLoggedIn(true);
      setShowPasswordInput(false);
      toast({
        title: "✅ تم تسجيل الدخول",
        description: "مرحباً بك في لوحة الإدارة"
      });
    } else {
      toast({
        title: "❌ كلمة مرور خاطئة",
        description: "يرجى المحاولة مرة أخرى",
        variant: "destructive"
      });
    }
  };

  const approveRequest = (requestId: string, userCode: string) => {
    console.log('Approving request:', requestId, userCode);
    
    // Update withdraw requests status
    const withdrawRequests = JSON.parse(localStorage.getItem('withdrawRequests') || '[]');
    const withdrawRequestIndex = withdrawRequests.findIndex((req: any) => req.id === requestId);
    
    if (withdrawRequestIndex !== -1) {
      withdrawRequests[withdrawRequestIndex].status = 'completed';
      localStorage.setItem('withdrawRequests', JSON.stringify(withdrawRequests));
      console.log('Updated withdraw requests:', withdrawRequests);
    }

    // IMPORTANT: Also update withdrawRecords to fix the issue
    const withdrawRecords = JSON.parse(localStorage.getItem('withdrawRecords') || '[]');
    const recordIndex = withdrawRecords.findIndex((record: any) => record.id === requestId);
    
    if (recordIndex !== -1) {
      withdrawRecords[recordIndex].status = 'completed';
      localStorage.setItem('withdrawRecords', JSON.stringify(withdrawRecords));
      console.log('Updated withdraw records:', withdrawRecords);
    }

    // Send approval message
    const approvalMessage: Message = {
      id: Date.now().toString(),
      title: "تم قبول طلبك",
      content: "تم قبول طلبك\n\nفي انتظار الطابور، دورك قريب",
      type: 'announcement',
      timestamp: new Date(),
      isRead: false,
      recipientType: 'specific',
      targetUserCode: userCode
    };

    const updatedMessages = [approvalMessage, ...userMessages];
    setUserMessages(updatedMessages);
    localStorage.setItem('userMessages', JSON.stringify(updatedMessages));

    // Update request status in state
    const updatedRequests = adminRequests.map(req => 
      req.id === requestId ? { ...req, status: 'handled' as const } : req
    );
    setAdminRequests(updatedRequests);

    toast({
      title: "✅ تم قبول الطلب",
      description: `تم إرسال رسالة الموافقة للمستخدم ${userCode}`
    });
  };

  const sendMessageToUsers = () => {
    if (!newMessage.title || !newMessage.content) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول",
        variant: "destructive"
      });
      return;
    }

    if (newMessage.recipientType === 'specific' && !newMessage.targetUserCode) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال كود المستخدم",
        variant: "destructive"
      });
      return;
    }

    const message: Message = {
      id: Date.now().toString(),
      title: newMessage.title,
      content: newMessage.content,
      type: newMessage.type,
      timestamp: new Date(),
      isRead: false,
      recipientType: newMessage.recipientType,
      targetUserCode: newMessage.recipientType === 'specific' ? newMessage.targetUserCode : undefined
    };

    const updatedMessages = [message, ...userMessages];
    setUserMessages(updatedMessages);
    localStorage.setItem('userMessages', JSON.stringify(updatedMessages));

    setNewMessage({ 
      title: '', 
      content: '', 
      type: 'info',
      recipientType: 'all',
      targetUserCode: '' 
    });
    
    const recipientText = newMessage.recipientType === 'all' 
      ? 'جميع المستخدمين' 
      : `المستخدم ${newMessage.targetUserCode}`;
    
    toast({
      title: "✅ تم إرسال الرسالة",
      description: `تم إرسال الرسالة إلى ${recipientText}`
    });
  };

  const markAsRead = (messageId: string) => {
    const updatedMessages = userMessages.map(msg => 
      msg.id === messageId ? { ...msg, isRead: true } : msg
    );
    setUserMessages(updatedMessages);
    localStorage.setItem('userMessages', JSON.stringify(updatedMessages));
  };

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'announcement': return '📢';
      case 'update': return '🆕';
      case 'warning': return '⚠️';
      default: return '💬';
    }
  };

  const getMessageColor = (type: string) => {
    switch (type) {
      case 'announcement': return 'bg-blue-500';
      case 'update': return 'bg-green-500';
      case 'warning': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  // Filter messages based on current user
  const currentUserMessages = userMessages.filter(msg => 
    msg.recipientType === 'all' || 
    (msg.recipientType === 'specific' && msg.targetUserCode === userCode)
  );

  const unreadCount = currentUserMessages.filter(msg => !msg.isRead).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-blue-900 to-indigo-900 p-4" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <Button
          onClick={() => onNavigate('home')}
          variant="ghost"
          className="text-white hover:bg-white/20"
        >
          <ArrowLeft className="w-5 h-5 ml-2" />
          الرجوع
        </Button>
        
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white flex items-center justify-center gap-2">
            <Code className="w-8 h-8" />
            💻 رسائل المطور
          </h1>
        </div>
        
        <div></div>
      </div>

      <Tabs defaultValue="user" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-white/10 backdrop-blur-sm">
          <TabsTrigger value="user" className="data-[state=active]:bg-white/20">
            <MessageCircle className="w-4 h-4 ml-1" />
            رسائل المستخدمين
            {unreadCount > 0 && (
              <Badge className="bg-red-500 text-white mr-2 text-xs">
                {unreadCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="admin" className="data-[state=active]:bg-white/20">
            <Shield className="w-4 h-4 ml-1" />
            لوحة الإدارة
            <Crown className="w-4 h-4 mr-1 text-yellow-400" />
          </TabsTrigger>
        </TabsList>

        <TabsContent value="user" className="space-y-4">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white text-center">
                📬 صندوق الرسائل الخاص بك
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentUserMessages.length === 0 ? (
                <div className="text-center text-white/70 py-8">
                  <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>لا توجد رسائل حالياً</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {currentUserMessages.map((message) => (
                    <Card 
                      key={message.id} 
                      className={`cursor-pointer transition-all hover:shadow-lg ${
                        message.isRead ? 'bg-white/5' : 'bg-white/15 border-blue-400'
                      }`}
                      onClick={() => markAsRead(message.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{getMessageIcon(message.type)}</span>
                            <h3 className="font-bold text-white">{message.title}</h3>
                            {!message.isRead && (
                              <Badge className="bg-blue-500 text-white text-xs">
                                جديد
                              </Badge>
                            )}
                            {message.recipientType === 'specific' && (
                              <Badge className="bg-purple-500 text-white text-xs">
                                رسالة خاصة
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-white/70">
                            {message.timestamp.toLocaleDateString('ar-SA')}
                          </span>
                        </div>
                        <p className="text-white/90 leading-relaxed">{message.content}</p>
                        {!message.isRead && (
                          <div className="mt-2 flex items-center gap-1 text-blue-300 text-sm">
                            <Eye className="w-3 h-3" />
                            اضغط لقراءة الرسالة
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="admin" className="space-y-4">
          {!isAdminLoggedIn ? (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white text-center flex items-center justify-center gap-2">
                  <Lock className="w-6 h-6" />
                  🔐 دخول الإدارة
                </CardTitle>
                <p className="text-white/70 text-center text-sm">
                  ⚠️ هذا القسم مخصص للمطور فقط
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                {!showPasswordInput ? (
                  <div className="text-center">
                    <Button
                      onClick={() => setShowPasswordInput(true)}
                      className="bg-red-600 hover:bg-red-700 text-white px-8 py-3"
                    >
                      <Shield className="w-5 h-5 ml-2" />
                      دخول لوحة الإدارة
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Input
                      type="password"
                      placeholder="كلمة المرور"
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      className="bg-white/20 border-white/30 text-white placeholder:text-white/50"
                      onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
                    />
                    <div className="flex gap-2">
                      <Button
                        onClick={handleAdminLogin}
                        className="bg-green-600 hover:bg-green-700 flex-1"
                      >
                        دخول
                      </Button>
                      <Button
                        onClick={() => setShowPasswordInput(false)}
                        variant="outline"
                        className="border-white/30 text-white hover:bg-white/10"
                      >
                        إلغاء
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Welcome Admin */}
              <Card className="bg-gradient-to-r from-green-600/20 to-blue-600/20 backdrop-blur-sm border-green-400/30">
                <CardContent className="p-4">
                  <div className="text-center text-white">
                    <Crown className="w-12 h-12 mx-auto mb-2 text-yellow-400" />
                    <h2 className="text-xl font-bold">مرحباً بك في لوحة الإدارة</h2>
                    <p className="text-sm opacity-90">يمكنك الآن إدارة الرسائل والطلبات</p>
                  </div>
                </CardContent>
              </Card>

              {/* Send Message to Users */}
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">📤 إرسال رسالة للمستخدمين</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Recipient Type Selection */}
                  <div className="space-y-2">
                    <label className="text-white text-sm font-medium">نوع المستقبل:</label>
                    <div className="flex gap-2">
                      <select
                        value={newMessage.recipientType}
                        onChange={(e) => setNewMessage({
                          ...newMessage, 
                          recipientType: e.target.value as 'all' | 'specific',
                          targetUserCode: e.target.value === 'all' ? '' : newMessage.targetUserCode
                        })}
                        className="bg-white/20 border border-white/30 rounded-md px-3 py-2 text-white flex-1"
                      >
                        <option value="all">جميع المستخدمين</option>
                        <option value="specific">مستخدم محدد</option>
                      </select>
                      {newMessage.recipientType === 'all' ? (
                        <Users className="w-8 h-8 text-blue-400 bg-white/20 rounded-md p-1" />
                      ) : (
                        <User className="w-8 h-8 text-purple-400 bg-white/20 rounded-md p-1" />
                      )}
                    </div>
                  </div>

                  {newMessage.recipientType === 'specific' && (
                    <div className="space-y-2">
                      <label className="text-white text-sm font-medium">كود المستخدم:</label>
                      <Input
                        placeholder="أدخل كود المستخدم"
                        value={newMessage.targetUserCode}
                        onChange={(e) => setNewMessage({...newMessage, targetUserCode: e.target.value})}
                        className="bg-white/20 border-white/30 text-white placeholder:text-white/50"
                      />
                    </div>
                  )}

                  <Input
                    placeholder="عنوان الرسالة"
                    value={newMessage.title}
                    onChange={(e) => setNewMessage({...newMessage, title: e.target.value})}
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/50"
                  />
                  <Textarea
                    placeholder="محتوى الرسالة"
                    value={newMessage.content}
                    onChange={(e) => setNewMessage({...newMessage, content: e.target.value})}
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/50"
                    rows={4}
                  />
                  <div className="flex gap-2">
                    <select
                      value={newMessage.type}
                      onChange={(e) => setNewMessage({...newMessage, type: e.target.value as any})}
                      className="bg-white/20 border border-white/30 rounded-md px-3 py-2 text-white"
                    >
                      <option value="info">معلومات عامة</option>
                      <option value="announcement">إعلان مهم</option>
                      <option value="update">تحديث جديد</option>
                      <option value="warning">تحذير</option>
                    </select>
                    <Button
                      onClick={sendMessageToUsers}
                      className="bg-blue-600 hover:bg-blue-700 flex-1"
                    >
                      <Send className="w-4 h-4 ml-2" />
                      {newMessage.recipientType === 'all' ? 'إرسال للجميع' : 'إرسال للمستخدم'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* User Requests */}
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">📋 طلبات المستخدمين</CardTitle>
                </CardHeader>
                <CardContent>
                  {adminRequests.length === 0 ? (
                    <div className="text-center text-white/70 py-8">
                      <AlertCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>لا توجد طلبات حالياً</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {adminRequests.map((request) => (
                        <Card key={request.id} className="bg-white/5">
                          <CardContent className="p-4">
                            <div className="space-y-3">
                              <div className="flex justify-between items-start">
                                <div>
                                  <Badge className={request.type === 'withdraw' ? 'bg-red-500' : 'bg-purple-500'}>
                                    {request.type === 'withdraw' ? 'طلب سحب' : 'طلب محتوى'}
                                  </Badge>
                                  <p className="text-white mt-1">
                                    المستخدم: <code className="bg-gray-700 px-1 rounded">{request.userCode}</code>
                                  </p>
                                  <p className="text-white/70 text-sm">
                                    {request.timestamp.toLocaleString('ar-SA')}
                                  </p>
                                </div>
                                <Badge variant={request.status === 'pending' ? 'secondary' : 'default'}>
                                  {request.status === 'pending' ? 'قيد الانتظار' : 'تم المعالجة'}
                                </Badge>
                              </div>

                              {/* Request Details - Always Displayed */}
                              <div className="bg-gray-700 p-3 rounded-lg">
                                {request.type === 'withdraw' ? (
                                  <div className="space-y-2 text-white/90">
                                    <p><span className="font-bold">مبلغ الشدات:</span> {request.details.ucAmount}</p>
                                    <p><span className="font-bold">معرف اللعبة:</span> {request.details.gameId}</p>
                                    <p><span className="font-bold">معرف الطلب:</span> {request.details.id}</p>
                                  </div>
                                ) : (
                                  <div className="space-y-2 text-white/90">
                                    <p><span className="font-bold">معرف القناة:</span> {request.details.channelId}</p>
                                    <p><span className="font-bold">رابط الفيديو:</span> 
                                      <a href={request.details.videoLink} target="_blank" rel="noopener noreferrer" 
                                         className="text-blue-400 underline ml-1 break-all">
                                        {request.details.videoLink}
                                      </a>
                                    </p>
                                  </div>
                                )}
                              </div>

                              {/* Action Buttons */}
                              {request.status === 'pending' && (
                                <div className="flex gap-2">
                                  <Button 
                                    size="sm" 
                                    onClick={() => approveRequest(request.id, request.userCode)}
                                    className="bg-green-600 hover:bg-green-700"
                                  >
                                    <Check className="w-4 h-4 ml-1" />
                                    موافقة
                                  </Button>
                                </div>
                              )}

                              {request.status === 'handled' && (
                                <div className="bg-green-100 border border-green-300 rounded p-2">
                                  <p className="text-green-800 text-sm">
                                    ✅ تم قبول هذا الطلب وإرسال رسالة للمستخدم
                                  </p>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DeveloperMessagesPage;
