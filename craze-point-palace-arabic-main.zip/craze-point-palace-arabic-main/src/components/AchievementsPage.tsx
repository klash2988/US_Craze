
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { ArrowRight, Trophy, Play, Users, CheckCircle, Gift } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';

interface AchievementsPageProps {
  onBack: () => void;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  target: number;
  reward: number;
  rewardType: 'points' | 'uc';
  icon: React.ReactNode;
  type: 'ads' | 'bigAds' | 'referrals';
  completed: boolean;
  current: number;
  claimed: boolean;
}

const AchievementsPage = ({ onBack }: AchievementsPageProps) => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [pendingRewards, setPendingRewards] = useState({ points: 0, uc: 0 });
  const { toast } = useToast();
  const { t } = useLanguage();

  useEffect(() => {
    loadAchievements();
    calculatePendingRewards();
  }, []);

  const loadAchievements = () => {
    const adsWatched = parseInt(localStorage.getItem('totalAdsWatched') || '0');
    
    // Calculate valid referrals (users who watched at least 51 ads)
    const totalReferrals = parseInt(localStorage.getItem('totalReferrals') || '0');
    const validReferrals = Math.min(totalReferrals, Math.floor(adsWatched / 51));
    
    const claimedAchievements = JSON.parse(localStorage.getItem('claimedAchievements') || '[]');

    const achievementsList: Achievement[] = [
      {
        id: 'ads299',
        title: 'مشاهد الإعلانات المبتدئ',
        description: 'شاهد 299 إعلان',
        target: 299,
        reward: 400,
        rewardType: 'points',
        icon: <Play className="w-8 h-8 text-green-500" />,
        type: 'ads',
        completed: adsWatched >= 299,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads299')
      },
      {
        id: 'ads1000',
        title: 'ملك الإعلانات',
        description: 'شاهد 1000 إعلان',
        target: 1000,
        reward: 2000,
        rewardType: 'points',
        icon: <Trophy className="w-8 h-8 text-gold-500" />,
        type: 'bigAds',
        completed: adsWatched >= 1000,
        current: adsWatched,
        claimed: claimedAchievements.includes('ads1000')
      },
      {
        id: 'referrals5',
        title: 'داعي الأصدقاء',
        description: 'ادع 5 أصدقاء',
        target: 5,
        reward: 1000,
        rewardType: 'points',
        icon: <Users className="w-8 h-8 text-blue-500" />,
        type: 'referrals',
        completed: validReferrals >= 5,
        current: validReferrals,
        claimed: claimedAchievements.includes('referrals5')
      },
      {
        id: 'referrals20',
        title: 'محترف الدعوات',
        description: 'ادع 20 صديق',
        target: 20,
        reward: 30,
        rewardType: 'uc',
        icon: <Users className="w-8 h-8 text-purple-500" />,
        type: 'referrals',
        completed: validReferrals >= 20,
        current: validReferrals,
        claimed: claimedAchievements.includes('referrals20')
      },
      {
        id: 'referrals140',
        title: 'ملك الدعوات',
        description: 'ادع 140 شخص',
        target: 140,
        reward: 325,
        rewardType: 'uc',
        icon: <Trophy className="w-8 h-8 text-orange-500" />,
        type: 'referrals',
        completed: validReferrals >= 140,
        current: validReferrals,
        claimed: claimedAchievements.includes('referrals140')
      }
    ];

    setAchievements(achievementsList);
  };

  const calculatePendingRewards = () => {
    const pendingAchievementRewards = JSON.parse(localStorage.getItem('pendingAchievementRewards') || '{"points": 0, "uc": 0}');
    setPendingRewards(pendingAchievementRewards);
  };

  const claimReward = (achievement: Achievement) => {
    if (achievement.claimed) {
      toast({
        title: "تم استلام المكافأة مسبقاً",
        description: "لقد حصلت على هذه المكافأة من قبل",
        variant: "destructive"
      });
      return;
    }

    if (!achievement.completed) {
      toast({
        title: "الإنجاز غير مكتمل",
        description: "أكمل الإنجاز أولاً للحصول على المكافأة",
        variant: "destructive"
      });
      return;
    }

    // إضافة المكافأة إلى النقاط المعلقة
    const currentPending = JSON.parse(localStorage.getItem('pendingAchievementRewards') || '{"points": 0, "uc": 0}');
    if (achievement.rewardType === 'points') {
      currentPending.points += achievement.reward;
    } else {
      currentPending.uc += achievement.reward;
    }
    localStorage.setItem('pendingAchievementRewards', JSON.stringify(currentPending));
    
    // تحديث قائمة الإنجازات المطالب بها
    const claimedAchievements = JSON.parse(localStorage.getItem('claimedAchievements') || '[]');
    claimedAchievements.push(achievement.id);
    localStorage.setItem('claimedAchievements', JSON.stringify(claimedAchievements));

    // تحديث حالة الإنجازات
    setAchievements(prev => prev.map(ach => 
      ach.id === achievement.id ? { ...ach, claimed: true } : ach
    ));

    // تحديث المكافآت المعلقة
    setPendingRewards(currentPending);

    const rewardText = achievement.rewardType === 'points' ? 'نقطة' : 'شدة';
    toast({
      title: "تم طلب المكافأة! 🎁",
      description: `تم إضافة ${achievement.reward} ${rewardText} للمكافآت المعلقة!`
    });
  };

  const collectAllRewards = () => {
    if (pendingRewards.points === 0 && pendingRewards.uc === 0) {
      toast({
        title: "لا توجد مكافآت معلقة",
        description: "اطلب مكافآت الإنجازات أولاً",
        variant: "destructive"
      });
      return;
    }

    // إضافة النقاط والشدات إلى الرصيد
    if (pendingRewards.points > 0) {
      const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
      const newPoints = currentPoints + pendingRewards.points;
      localStorage.setItem('pointsBalance', newPoints.toString());
    }

    if (pendingRewards.uc > 0) {
      const currentUC = parseInt(localStorage.getItem('totalUCWon') || '0');
      const newUC = currentUC + pendingRewards.uc;
      localStorage.setItem('totalUCWon', newUC.toString());
    }

    // مسح المكافآت المعلقة
    localStorage.setItem('pendingAchievementRewards', '{"points": 0, "uc": 0}');
    setPendingRewards({ points: 0, uc: 0 });

    toast({
      title: "تم تجميع جميع المكافآت! 🎉",
      description: `تم إضافة ${pendingRewards.points} نقطة و ${pendingRewards.uc} شدة إلى رصيدك!`
    });
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 p-4" dir="rtl">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={onBack} className="text-white">
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white mr-4">الإنجازات 🏆</h1>
        </div>

        {/* Pending Rewards Section */}
        {(pendingRewards.points > 0 || pendingRewards.uc > 0) && (
          <div className="bg-yellow-500/20 backdrop-blur-sm rounded-lg p-4 mb-6 border border-yellow-400/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Gift className="w-6 h-6 text-yellow-300" />
                <h3 className="font-bold text-white">المكافآت المعلقة</h3>
              </div>
            </div>
            <div className="flex justify-between items-center mb-4">
              <div className="text-white">
                {pendingRewards.points > 0 && <span>{pendingRewards.points} نقطة</span>}
                {pendingRewards.points > 0 && pendingRewards.uc > 0 && <span> • </span>}
                {pendingRewards.uc > 0 && <span>{pendingRewards.uc} شدة</span>}
              </div>
            </div>
            <Button
              onClick={collectAllRewards}
              className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
            >
              تجميع جميع المكافآت 🎁
            </Button>
          </div>
        )}

        <div className="space-y-4">
          {achievements.map((achievement) => (
            <div key={achievement.id} className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  {achievement.icon}
                  <div>
                    <h3 className="font-bold text-white">{achievement.title}</h3>
                    <p className="text-sm text-white/80">{achievement.description}</p>
                  </div>
                </div>
                {achievement.claimed && <CheckCircle className="w-6 h-6 text-green-400" />}
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-white/90 mb-2">
                  <span>{achievement.current}/{achievement.target}</span>
                  <span>{Math.round(getProgressPercentage(achievement.current, achievement.target))}%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-yellow-400 to-orange-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${getProgressPercentage(achievement.current, achievement.target)}%` }}
                  ></div>
                </div>
              </div>

              {/* Reward Info */}
              <div className="bg-white/20 rounded p-3 mb-4">
                <p className="text-white text-sm">
                  المكافأة: {achievement.reward} {achievement.rewardType === 'points' ? 'نقطة' : 'شدة'}
                </p>
              </div>

              {/* Claim Button */}
              <Button
                onClick={() => claimReward(achievement)}
                disabled={!achievement.completed || achievement.claimed}
                className={`w-full ${
                  achievement.completed && !achievement.claimed
                    ? 'bg-green-600 hover:bg-green-700' 
                    : achievement.completed && achievement.claimed
                    ? 'bg-gray-600'
                    : 'bg-gray-500'
                } text-white`}
              >
                {achievement.claimed 
                  ? 'تم الطلب ✅' 
                  : achievement.completed 
                  ? 'اطلب المكافأة 🎁' 
                  : `${achievement.target - achievement.current} متبقي`}
              </Button>
            </div>
          ))}

          {/* Info */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <h3 className="font-bold text-white mb-2">ملاحظات:</h3>
            <ul className="text-sm text-white/90 space-y-1">
              <li>• أكمل الأهداف لتحصل على المكافآت</li>
              <li>• كل مكافأة يمكن طلبها مرة واحدة فقط</li>
              <li>• تتم مراقبة التقدم تلقائياً</li>
              <li className="text-yellow-300 font-bold">• لا تحسب الدعوة إلا عند مشاهدة المستخدم 51 إعلان بحد أدنى</li>
              <li className="text-green-300 font-bold">• نقاط الإعلانات تُضاف تلقائياً، مكافآت الإنجازات تُجمع يدوياً</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AchievementsPage;
