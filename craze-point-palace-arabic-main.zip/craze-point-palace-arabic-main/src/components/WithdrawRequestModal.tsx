import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { X, Clock, CheckCircle, XCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface WithdrawRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface WithdrawRecord {
  id: string;
  pubgId: string;
  ucType: string;
  ucRequired: number;
  pointsCost: number;
  goldenPointsCost: number;
  notes: string;
  userId: string;
  userName: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'rejected';
}

const WithdrawRequestModal = ({ isOpen, onClose, onSuccess }: WithdrawRequestModalProps) => {
  const [pubgId, setPubgId] = useState('');
  const [ucType, setUcType] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [withdrawRecords, setWithdrawRecords] = useState<WithdrawRecord[]>([]);
  const { toast } = useToast();

  const userId = localStorage.getItem('userId') ||localStorage.getItem('userCode') || '';
  const userName = localStorage.getItem('userName') || 'مستخدم';
  const totalUC = parseInt(localStorage.getItem('totalUCWon') || '0');
  const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
  const goldenPoints = parseInt(localStorage.getItem('goldenPoints') || '0');

  // Load withdraw records on component mount
  useEffect(() => {
    if (isOpen) {
      loadWithdrawRecords();
      checkForStatusUpdates();
    }
  }, [isOpen]);

  const loadWithdrawRecords = () => {
    const records = JSON.parse(localStorage.getItem('withdrawRecords') || '[]');
    const userRecords = records.filter((record: WithdrawRecord) => record.userId === userId);
    setWithdrawRecords(userRecords);
  };

  const checkForStatusUpdates = () => {
    const messages = JSON.parse(localStorage.getItem('developerMessages') || '[]');
    const userMessages = messages.filter((msg: any) => 
      msg.targetUserCode === userId && 
      msg.message.includes('تم قبول طلب السحب') ||
      msg.message.includes('تم رفض طلب السحب')
    );

    if (userMessages.length > 0) {
      const records = JSON.parse(localStorage.getItem('withdrawRecords') || '[]');
      let updated = false;

      userMessages.forEach((msg: any) => {
        const recordIndex = records.findIndex((record: WithdrawRecord) => 
          record.userId === userId && record.status === 'pending'
        );
        
        if (recordIndex !== -1) {
          if (msg.message.includes('تم قبول طلب السحب')) {
            records[recordIndex].status = 'completed';
            updated = true;
          } else if (msg.message.includes('تم رفض طلب السحب')) {
            records[recordIndex].status = 'rejected';
            updated = true;
          }
        }
      });

      if (updated) {
        localStorage.setItem('withdrawRecords', JSON.stringify(records));
        loadWithdrawRecords();
      }
    }
  };

  // Calculate cost and required UC based on selection
  const getRequirements = (type: string) => {
    switch (type) {
      case '60 UC':
        return { ucRequired: 60, pointsCost: 2100, goldenPointsCost: 120 };
      case '325 UC':
        return { ucRequired: 325, pointsCost: 13000, goldenPointsCost: 670 };
      case '660 UC':
        return { ucRequired: 660, pointsCost: 25000, goldenPointsCost: 1999 };
      default:
        return { ucRequired: 0, pointsCost: 0, goldenPointsCost: 0 };
    }
  };

  // Check if user can access a withdrawal option
  const canAccessOption = (type: string) => {
    const { ucRequired, pointsCost, goldenPointsCost } = getRequirements(type);
    return totalUC >= ucRequired && currentPoints >= pointsCost && goldenPoints >= goldenPointsCost;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!pubgId || !ucType) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }

    const { ucRequired, pointsCost, goldenPointsCost } = getRequirements(ucType);

    // Check if user has enough golden points first with attractive error message
    if (goldenPoints < goldenPointsCost) {
      const neededGoldenPoints = goldenPointsCost - goldenPoints;
      toast({
        title: "🏅 النقاط الذهبية غير كافية!",
        description: (
          <div className="space-y-3 p-2">
            <div className="bg-gradient-to-r from-yellow-100 to-orange-100 p-3 rounded-lg border border-yellow-200">
              <p className="text-yellow-800 font-bold text-center">
                💰 تحتاج إلى {neededGoldenPoints.toLocaleString()} نقطة ذهبية إضافية
              </p>
            </div>
            <div className="bg-gradient-to-r from-green-100 to-blue-100 p-3 rounded-lg border border-green-200">
              <p className="text-green-800 font-bold text-center">
                🎬 شاهد الإعلانات لكسب النقاط الذهبية!
              </p>
              <p className="text-green-700 text-sm text-center mt-1">
                كل إعلان = نقطة ذهبية واحدة
              </p>
            </div>
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-2 rounded-lg border border-purple-200">
              <p className="text-purple-800 text-sm text-center font-medium">
                ⚡ ابدأ المشاهدة الآن واحصل على {neededGoldenPoints} نقطة!
              </p>
            </div>
          </div>
        ),
        variant: "destructive"
      });
      return;
    }

    // Check other requirements
    if (totalUC < ucRequired) {
      toast({
        title: "❌ الشدات غير كافية",
        description: `تحتاج ${ucRequired - totalUC} شدة إضافية`,
        variant: "destructive"
      });
      return;
    }

    if (currentPoints < pointsCost) {
      toast({
        title: "❌ النقاط غير كافية",
        description: `تحتاج ${(pointsCost - currentPoints).toLocaleString()} نقطة إضافية`,
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    // Deduct UC, points, and golden points from localStorage BEFORE sending the request
    const newTotalUC = Math.max(totalUC - ucRequired, 0);
    const newPoints = Math.max(currentPoints - pointsCost, 0);
    const newGoldenPoints = Math.max(goldenPoints - goldenPointsCost, 0);
    localStorage.setItem('totalUCWon', newTotalUC.toString());
    localStorage.setItem('pointsBalance', newPoints.toString());
    localStorage.setItem('goldenPoints', newGoldenPoints.toString());

    const formData = new FormData();
    formData.append('PUBG_ID', pubgId);
    formData.append('UC_Type', ucType);
    formData.append('Notes', notes || 'لا توجد');
    formData.append('User_ID', userId);
    formData.append('User_Name', userName);
    formData.append('_captcha', 'false');
    formData.append('_template', 'table');

    try {
      await fetch('https://formsubmit.co/klash29885@gmail.com', {
        method: 'POST',
        body: formData
      });

      // Create withdraw record
      const newRecord: WithdrawRecord = {
        id: Date.now().toString(),
        pubgId,
        ucType,
        ucRequired,
        pointsCost,
        goldenPointsCost,
        notes: notes || 'لا توجد',
        userId,
        userName,
        timestamp: new Date().toISOString(),
        status: 'pending'
      };

      // Save to localStorage
      const existingRecords = JSON.parse(localStorage.getItem('withdrawRecords') || '[]');
      existingRecords.push(newRecord);
      localStorage.setItem('withdrawRecords', JSON.stringify(existingRecords));

      // Also save for admin communication
      const adminRequests = JSON.parse(localStorage.getItem('withdrawRequests') || '[]');
      adminRequests.push({
        id: newRecord.id,
        userCode: userId,
        ucAmount: ucRequired,
        gameId: pubgId,
        timestamp: new Date(),
        status: 'pending'
      });
      localStorage.setItem('withdrawRequests', JSON.stringify(adminRequests));

      toast({
        title: "📬 تم إرسال طلبك بنجاح!",
        description: `تم خصم ${ucRequired} شدة و ${pointsCost} نقطة و ${goldenPointsCost} نقطة ذهبية. سيتم الرد خلال 24 ساعة.`
      });

      // Reset form
      setPubgId('');
      setUcType('');
      setNotes('');
      
      // Reload records
      loadWithdrawRecords();
      
      onSuccess();
    } catch (error) {
      // Restore points, UC, and golden points if request failed
      localStorage.setItem('totalUCWon', totalUC.toString());
      localStorage.setItem('pointsBalance', currentPoints.toString());
      localStorage.setItem('goldenPoints', goldenPoints.toString());
      
      toast({
        title: "خطأ في الإرسال",
        description: "حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedRequirements = getRequirements(ucType);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'انتظار';
      case 'completed':
        return 'تم';
      case 'rejected':
        return 'مرفوض';
      default:
        return 'غير معروف';
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending':
        return 'secondary' as const;
      case 'completed':
        return 'default' as const;
      case 'rejected':
        return 'destructive' as const;
      default:
        return 'secondary' as const;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl mx-auto max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">سحب الشدات</DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute left-4 top-4"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>
        
        <div className="p-4">
          <Tabs defaultValue="request" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="request">طلب جديد</TabsTrigger>
              <TabsTrigger value="records">
                السجلات ({withdrawRecords.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="request" className="space-y-4">
              <div className="text-center mb-4 bg-gray-50 p-3 rounded-lg">
                <p className="text-sm font-bold mb-2">💎 رصيدك الحالي:</p>
                <p className="text-sm">👤 الاسم: {userName}</p>
                <p className="text-sm">🆔 المعرف: {userId}</p>
                <div className="flex justify-center gap-4 mt-2">
                  <p className="text-sm">🔹 شدات: {totalUC}</p>
                  <p className="text-sm">🔸 نقاط: {currentPoints.toLocaleString()}</p>
                  <p className="text-sm">🏅 نقاط ذهبية: {goldenPoints.toLocaleString()}</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="ucType">اختر نوع السحب *</Label>
                  <Select value={ucType} onValueChange={setUcType} required>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر نوع السحب" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="60 UC">60 UC (2,100 نقطة + 120 نقطة ذهبية)</SelectItem>
                      <SelectItem value="325 UC">325 UC (13,000 نقطة + 670 نقطة ذهبية)</SelectItem>
                      <SelectItem value="660 UC">660 UC (25,000 نقطة + 1,999 نقطة ذهبية)</SelectItem>
                    </SelectContent>
                  </Select>
                  {ucType && (
                    <p className="text-xs text-gray-600 mt-1">
                      المطلوب: {selectedRequirements.ucRequired} شدة + {selectedRequirements.pointsCost.toLocaleString()} نقطة + {selectedRequirements.goldenPointsCost.toLocaleString()} نقطة ذهبية
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="pubgId">معرف ببجي *</Label>
                  <Input
                    id="pubgId"
                    value={pubgId}
                    onChange={(e) => setPubgId(e.target.value)}
                    placeholder="أدخل معرف PUBG الخاص بك"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="notes">ملاحظات (اختياري)</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="أي ملاحظات إضافية..."
                    rows={3}
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting || !ucType}
                  className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                >
                  {isSubmitting ? 'جاري الإرسال...' : '✅ إرسال الطلب'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="records" className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-bold text-blue-800 mb-3">📋 سجل طلبات السحب</h3>
                {withdrawRecords.length === 0 ? (
                  <p className="text-gray-600 text-center py-4">لا توجد طلبات سحب</p>
                ) : (
                  <div className="space-y-3">
                    {withdrawRecords.map((record) => (
                      <div key={record.id} className="bg-white p-4 rounded-lg border shadow-sm">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-bold text-gray-700">نوع السحب:</span>
                              <span className="text-blue-600 font-medium">{record.ucType}</span>
                            </div>
                            <p className="text-sm text-gray-600 mb-1">
                              <span className="font-medium">معرف ببجي:</span> {record.pubgId}
                            </p>
                            <p className="text-sm text-gray-600 mb-1">
                              <span className="font-medium">المبلغ المخصوم:</span> {record.ucRequired} شدة + {record.pointsCost.toLocaleString()} نقطة + {record.goldenPointsCost?.toLocaleString() || 0} نقطة ذهبية
                            </p>
                            {record.notes && (
                              <p className="text-sm text-gray-600 mb-1">
                                <span className="font-medium">ملاحظات:</span> {record.notes}
                              </p>
                            )}
                            <p className="text-xs text-gray-500">
                              {new Date(record.timestamp).toLocaleString('ar-SA')}
                            </p>
                          </div>
                          <div className="flex flex-col items-center gap-2">
                            {getStatusIcon(record.status)}
                            <Badge variant={getStatusBadgeVariant(record.status)}>
                              {getStatusText(record.status)}
                            </Badge>
                          </div>
                        </div>
                        
                        {record.status === 'pending' && (
                          <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mt-2">
                            <p className="text-xs text-yellow-700">
                              ⏰ طلبك قيد المراجعة. سيتم الرد خلال 24 ساعة.
                            </p>
                          </div>
                        )}
                        
                        {record.status === 'completed' && (
                          <div className="bg-green-50 border border-green-200 rounded p-2 mt-2">
                            <p className="text-xs text-green-700">
                              ✅ تم تنفيذ طلبك بنجاح!
                            </p>
                          </div>
                        )}
                        
                        {record.status === 'rejected' && (
                          <div className="bg-red-50 border border-red-200 rounded p-2 mt-2">
                            <p className="text-xs text-red-700">
                              ❌ تم رفض طلبك. تحقق من الرسائل للتفاصيل.
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WithdrawRequestModal;
