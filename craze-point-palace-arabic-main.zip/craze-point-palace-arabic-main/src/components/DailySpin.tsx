import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { X } from 'lucide-react';

interface DailySpinProps {
  onClose: () => void;
  onReward: (points: number) => void;
}

const DailySpin = ({ onClose, onReward }: DailySpinProps) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [canSpin, setCanSpin] = useState(true);
  const [rotation, setRotation] = useState(0);
  const [currentStreak, setCurrentStreak] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const { toast } = useToast();

  // Weekly reward cycle: Day 1=100, Day 2=50, Day 3=80, Day 4=20, Day 5=50, Day 6=20, Day 7=199
  const weeklyRewards = [100, 50, 80, 20, 50, 20, 199];
  
  // Display values for the wheel - visual only
  const wheelDisplayValues = [999, 100, 199, 50, 20, 80];

  // Create segments for the wheel using display values
  const segments = wheelDisplayValues.map((value, index) => ({
    label: `${value}`,
    value: value,
    color: [
      "#e74c3c", "#3498db", "#2ecc71", "#f39c12", "#9b59b6", "#e67e22"
    ][index],
    textColor: "#fff"
  }));

  useEffect(() => {
    const lastSpin = localStorage.getItem('lastDailySpin');
    const streakData = localStorage.getItem('dailySpinStreak');
    const today = new Date().toDateString();
    
    if (lastSpin === today) {
      setCanSpin(false);
    }

    // Handle streak calculation
    if (streakData) {
      const { streak, lastDate } = JSON.parse(streakData);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayString = yesterday.toDateString();
      
      if (lastDate === yesterdayString) {
        // Continuous streak
        setCurrentStreak(streak);
      } else if (lastDate === today) {
        // Already played today
        setCurrentStreak(streak);
      } else {
        // Streak broken, reset to 0
        setCurrentStreak(0);
        localStorage.setItem('dailySpinStreak', JSON.stringify({ streak: 0, lastDate: '' }));
      }
    } else {
      setCurrentStreak(0);
    }
  }, []);

  const getTodaysReward = () => {
    return weeklyRewards[currentStreak % 7];
  };

  const handleSpin = () => {
    if (!canSpin || isSpinning) return;

    setIsSpinning(true);
    
    // Get actual reward from weekly cycle
    const reward = getTodaysReward();
    const newStreak = currentStreak + 1;
    
    // Update streak data
    const today = new Date().toDateString();
    localStorage.setItem('dailySpinStreak', JSON.stringify({ 
      streak: newStreak, 
      lastDate: today 
    }));
    setCurrentStreak(newStreak);
    
    // Calculate wheel rotation for visual effect
    const spins = Math.floor(Math.random() * 5) + 8;
    const segmentAngle = 360 / wheelDisplayValues.length; // 60 degrees per segment
    const randomSegmentIndex = Math.floor(Math.random() * wheelDisplayValues.length);
    const finalAngle = randomSegmentIndex * segmentAngle + Math.random() * segmentAngle;
    const totalRotation = rotation + (360 * spins) + finalAngle;
    
    setRotation(totalRotation);

    // Show confetti effect
    setShowConfetti(true);
    
    setTimeout(() => {
      setShowConfetti(false);
    }, 3000);

    setTimeout(() => {
      setIsSpinning(false);
      localStorage.setItem('lastDailySpin', today);
      setCanSpin(false);
      onReward(reward);
      
      // Vibration effect
      if (navigator.vibrate) {
        navigator.vibrate([200, 100, 600]);
      }
      
      toast({
        title: "🎉 مبروك! لقد ربحت!",
        description: `فزت بـ ${reward} نقطة! سلسلة الأيام: ${newStreak}`
      });

      setTimeout(() => {
        onClose();
      }, 2500);
    }, 4500);
  };

  const getStreakDay = () => {
    const dayNames = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع'];
    return dayNames[currentStreak % 7];
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-sm mx-auto bg-gradient-to-br from-[#fff6e5] to-[#ffe4c4] relative overflow-hidden border-0 shadow-2xl fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 max-h-screen" dir="rtl">
        {/* Confetti Effect */}
        {showConfetti && (
          <div className="absolute inset-0 pointer-events-none z-50">
            {[...Array(80)].map((_, i) => (
              <div
                key={i}
                className="absolute w-3 h-3 animate-bounce"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  backgroundColor: ['#FFD700', '#FF5722', '#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#00BCD4', '#E91E63'][Math.floor(Math.random() * 8)],
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${1 + Math.random() * 2}s`,
                  borderRadius: ['50%', '0%'][Math.floor(Math.random() * 2)],
                  transform: `rotate(${Math.random() * 360}deg)`
                }}
              />
            ))}
          </div>
        )}

        <DialogHeader className="pb-2 pt-2">
          <DialogTitle className="text-center text-xl font-bold bg-gradient-to-r from-[#f54c1e] to-[#ff7a00] bg-clip-text text-transparent">
            🎡 العجلة اليومية
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute left-4 top-4 hover:bg-white/30 rounded-full"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>
        
        <div className="flex flex-col items-center justify-center space-y-3 p-3 pb-4 overflow-y-auto">
          {/* Subtitle */}
          <div className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-2 w-full border border-blue-100">
            <p className="text-xs text-[#5e5e5e] font-medium">
              🌟 ادر العجلة واحصل على نقاط يومياً!
            </p>
            <p className="text-xs text-gray-500 mt-1">
              🔥 سلسلة الأيام: {currentStreak} يوم
            </p>
          </div>

          {/* Motivational Text */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl p-3 shadow-lg">
              <p className="text-lg font-bold text-white mb-1">
                🎯 اليوم {getStreakDay()}! 🎯
              </p>
              <p className="text-sm text-orange-100">
                💫 جائزتك اليوم: {getTodaysReward()} نقطة! 💫
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 bg-white/70 rounded-full px-3 py-1 backdrop-blur-sm mt-2">
              <span className="text-xs font-medium text-gray-700">📅 اليوم:</span>
              <span className="text-sm font-bold text-[#FF522E]">{getStreakDay()}</span>
            </div>
          </div>

          {/* Spinning Wheel */}
          <div className="relative flex items-center justify-center">
            {/* Pointer Arrow */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-3 z-10">
              <div className="w-0 h-0 border-l-6 border-r-6 border-b-8 border-l-transparent border-r-transparent border-b-[#FF522E] drop-shadow-lg"></div>
            </div>
            
            {/* Wheel Container */}
            <div className="relative">
              <div 
                className={`w-40 h-40 rounded-full border-4 border-[#FF7D00] shadow-2xl transition-transform ease-out ${isSpinning ? 'duration-[4500ms]' : 'duration-300'} bg-gradient-to-br from-yellow-100 to-orange-100`}
                style={{ transform: `rotate(${rotation}deg)` }}
              >
                {/* Wheel Segments */}
                <svg viewBox="0 0 200 200" className="w-full h-full">
                  {segments.map((segment, index) => {
                    const angle = (360 / segments.length) * index;
                    const nextAngle = (360 / segments.length) * (index + 1);
                    
                    const startAngle = (angle * Math.PI) / 180;
                    const endAngle = (nextAngle * Math.PI) / 180;
                    
                    const x1 = 100 + 85 * Math.cos(startAngle);
                    const y1 = 100 + 85 * Math.sin(startAngle);
                    const x2 = 100 + 85 * Math.cos(endAngle);
                    const y2 = 100 + 85 * Math.sin(endAngle);
                    
                    const largeArcFlag = (nextAngle - angle) > 180 ? 1 : 0;
                    const pathData = `M 100 100 L ${x1} ${y1} A 85 85 0 ${largeArcFlag} 1 ${x2} ${y2} Z`;
                    
                    const textAngle = (startAngle + endAngle) / 2;
                    const textX = 100 + 55 * Math.cos(textAngle);
                    const textY = 100 + 55 * Math.sin(textAngle);
                    
                    return (
                      <g key={index}>
                        <path
                          d={pathData}
                          fill={segment.color}
                          stroke="#FF7D00"
                          strokeWidth="2"
                        />
                        <text
                          x={textX}
                          y={textY}
                          textAnchor="middle"
                          dominantBaseline="central"
                          fill={segment.textColor}
                          fontSize="10"
                          fontWeight="bold"
                          className="pointer-events-none"
                        >
                          {segment.label}
                        </text>
                      </g>
                    );
                  })}
                </svg>
                
                {/* Center Circle */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-gradient-to-br from-[#FF7D00] to-[#FF522E] rounded-full border-4 border-white shadow-xl flex items-center justify-center">
                  <span className="text-white font-bold text-xs">🎡</span>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="text-center space-y-1 bg-white/50 rounded-xl p-2 w-full backdrop-blur-sm">
            <p className="text-xs text-gray-600">🎁 مجاني يومياً | 🔥 سلسلة: {currentStreak} يوم</p>
            <p className="text-xs font-medium text-green-600">🌟 اجعل الحظ حليفك واربح أكثر!</p>
          </div>

          {/* Spin Button */}
          <Button
            onClick={handleSpin}
            disabled={!canSpin || isSpinning}
            className="w-full bg-gradient-to-r from-[#FF522E] to-[#e03e1a] hover:from-[#e03e1a] hover:to-[#c62d0f] text-white font-bold py-3 text-sm rounded-xl shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          >
            {isSpinning ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                🌀 جاري الدوران...
              </div>
            ) : canSpin ? (
              <div className="flex items-center gap-2">
                🎡 ادر العجلة اليومية
                <span className="text-yellow-300">✨</span>
              </div>
            ) : (
              '✅ تم الاستخدام اليوم'
            )}
          </Button>

          {!canSpin && !isSpinning && (
            <div className="text-center bg-gradient-to-r from-gray-100 to-gray-200 rounded-xl p-2 w-full">
              <p className="text-sm text-gray-600">
                ⏰ عد غداً لتواصل سلسلة الأيام!
              </p>
            </div>
          )}

          {/* Back Button */}
          <Button
            onClick={onClose}
            variant="outline"
            className="w-full bg-gradient-to-r from-gray-100 to-gray-200 hover:from-gray-200 hover:to-gray-300 text-gray-700 border-gray-300 rounded-xl py-2 shadow-lg"
          >
            ⬅ العودة للرئيسية
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DailySpin;
