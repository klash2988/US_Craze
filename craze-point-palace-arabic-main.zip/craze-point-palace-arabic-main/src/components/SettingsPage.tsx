
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ArrowRight, Moon, Sun, Globe, Bug } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';

interface SettingsPageProps {
  onBack: () => void;
}

const SettingsPage = ({ onBack }: SettingsPageProps) => {
  const [darkMode, setDarkMode] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    // Load settings from localStorage
    const savedDarkMode = localStorage.getItem('darkMode') === 'true';
    setDarkMode(savedDarkMode);
    
    // Apply theme to document on component mount
    if (savedDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const handleDarkModeToggle = (checked: boolean) => {
    setDarkMode(checked);
    localStorage.setItem('darkMode', checked.toString());
    
    // Apply theme to document immediately
    if (checked) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    // Force a re-render by dispatching a custom event
    window.dispatchEvent(new Event('darkModeToggle'));
  };

  const handleLanguageToggle = (checked: boolean) => {
    const newLanguage = checked ? 'en' : 'ar';
    setLanguage(newLanguage);
  };

  const handleReportBug = () => {
    const userCode = localStorage.getItem('userCode') || '';
    const subject = encodeURIComponent(language === 'ar' ? 'مشكلة في تطبيق UC Craze' : 'UC Craze App Issue');
    const body = encodeURIComponent(language === 'ar' ? `كود المستخدم: ${userCode}\n\nوصف المشكلة:` : `User Code: ${userCode}\n\nIssue Description:`);
    window.open(`mailto:klash29885@gmail.com?subject=${subject}&body=${body}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-600 via-gray-600 to-slate-700 p-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-white">
          {t('settingsTitle')}
        </h1>
      </div>

      {/* Settings Content */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mx-auto max-w-md shadow-lg space-y-6">
        
        {/* Dark Mode Toggle */}
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-3">
            {darkMode ? <Moon className="w-5 h-5 text-blue-600" /> : <Sun className="w-5 h-5 text-yellow-600" />}
            <Label htmlFor="darkMode" className="text-gray-800 font-medium">
              {t('darkMode')}
            </Label>
          </div>
          <Switch
            id="darkMode"
            checked={darkMode}
            onCheckedChange={handleDarkModeToggle}
          />
        </div>

        {/* Language Toggle */}
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-green-600" />
            <Label htmlFor="language" className="text-gray-800 font-medium">
              {t('switchToEnglish')}
            </Label>
          </div>
          <Switch
            id="language"
            checked={language === 'en'}
            onCheckedChange={handleLanguageToggle}
          />
        </div>

        {/* Report Bug Button */}
        <Button
          onClick={handleReportBug}
          className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 rounded-lg"
        >
          <Bug className="w-5 h-5 mr-2" />
          {t('reportBug')}
        </Button>

        {/* App Info */}
        <div className="text-center pt-4 border-t">
          <p className="text-gray-600 text-sm">{t('appVersion')}</p>
          <p className="text-gray-500 text-xs">
            {t('appDescription')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
