
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ArrowRight, Trophy, Star, Target, Users, Calendar, Gift, Crown } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';
import { getUserLevel } from '@/utils/levelSystem';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  requirement: number;
  currentProgress: number;
  reward: number;
  category: 'ads' | 'points' | 'referrals' | 'daily' | 'special';
  completed: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

interface EnhancedAchievementsProps {
  onBack: () => void;
}

const EnhancedAchievements = ({ onBack }: EnhancedAchievementsProps) => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const { language, t } = useLanguage();

  useEffect(() => {
    loadAchievements();
  }, []);

  const loadAchievements = () => {
    const totalAdsWatched = parseInt(localStorage.getItem('totalAdsWatched') || '0');
    const totalPoints = parseInt(localStorage.getItem('pointsBalance') || '0') + 
                       parseInt(localStorage.getItem('totalPointsEarned') || '0');
    const totalReferrals = parseInt(localStorage.getItem('totalReferrals') || '0');
    const daysActive = Math.floor((Date.now() - Date.parse(localStorage.getItem('joinDate') || new Date().toISOString())) / (1000 * 60 * 60 * 24)) + 1;

    const achievementsList: Achievement[] = [
      // إنجازات الإعلانات
      {
        id: 'first_ad',
        title: 'البداية',
        description: 'شاهد أول إعلان',
        icon: <Target className="w-6 h-6" />,
        requirement: 1,
        currentProgress: totalAdsWatched,
        reward: 50,
        category: 'ads',
        completed: totalAdsWatched >= 1,
        rarity: 'common'
      },
      {
        id: 'ads_10',
        title: 'متابع نشط',
        description: 'شاهد 10 إعلانات',
        icon: <Target className="w-6 h-6" />,
        requirement: 10,
        currentProgress: totalAdsWatched,
        reward: 200,
        category: 'ads',
        completed: totalAdsWatched >= 10,
        rarity: 'common'
      },
      {
        id: 'ads_50',
        title: 'عاشق الإعلانات',
        description: 'شاهد 50 إعلان',
        icon: <Target className="w-6 h-6" />,
        requirement: 50,
        currentProgress: totalAdsWatched,
        reward: 500,
        category: 'ads',
        completed: totalAdsWatched >= 50,
        rarity: 'rare'
      },
      {
        id: 'ads_100',
        title: 'ماستر الإعلانات',
        description: 'شاهد 100 إعلان',
        icon: <Crown className="w-6 h-6" />,
        requirement: 100,
        currentProgress: totalAdsWatched,
        reward: 1000,
        category: 'ads',
        completed: totalAdsWatched >= 100,
        rarity: 'epic'
      },
      {
        id: 'ads_500',
        title: 'أسطورة الإعلانات',
        description: 'شاهد 500 إعلان',
        icon: <Crown className="w-6 h-6" />,
        requirement: 500,
        currentProgress: totalAdsWatched,
        reward: 5000,
        category: 'ads',
        completed: totalAdsWatched >= 500,
        rarity: 'legendary'
      },
      
      // إنجازات النقاط
      {
        id: 'points_1000',
        title: 'جامع النقاط',
        description: 'اجمع 1000 نقطة',
        icon: <Star className="w-6 h-6" />,
        requirement: 1000,
        currentProgress: totalPoints,
        reward: 100,
        category: 'points',
        completed: totalPoints >= 1000,
        rarity: 'common'
      },
      {
        id: 'points_10000',
        title: 'ثري النقاط',
        description: 'اجمع 10,000 نقطة',
        icon: <Star className="w-6 h-6" />,
        requirement: 10000,
        currentProgress: totalPoints,
        reward: 1000,
        category: 'points',
        completed: totalPoints >= 10000,
        rarity: 'rare'
      },
      {
        id: 'points_50000',
        title: 'ملك النقاط',
        description: 'اجمع 50,000 نقطة',
        icon: <Crown className="w-6 h-6" />,
        requirement: 50000,
        currentProgress: totalPoints,
        reward: 5000,
        category: 'points',
        completed: totalPoints >= 50000,
        rarity: 'epic'
      },
      
      // إنجازات الإحالة
      {
        id: 'referral_1',
        title: 'أول صديق',
        description: 'ادع صديقاً واحداً',
        icon: <Users className="w-6 h-6" />,
        requirement: 1,
        currentProgress: totalReferrals,
        reward: 300,
        category: 'referrals',
        completed: totalReferrals >= 1,
        rarity: 'common'
      },
      {
        id: 'referral_5',
        title: 'منشر الخير',
        description: 'ادع 5 أصدقاء',
        icon: <Users className="w-6 h-6" />,
        requirement: 5,
        currentProgress: totalReferrals,
        reward: 1500,
        category: 'referrals',
        completed: totalReferrals >= 5,
        rarity: 'rare'
      },
      {
        id: 'referral_10',
        title: 'سفير التطبيق',
        description: 'ادع 10 أصدقاء',
        icon: <Crown className="w-6 h-6" />,
        requirement: 10,
        currentProgress: totalReferrals,
        reward: 3000,
        category: 'referrals',
        completed: totalReferrals >= 10,
        rarity: 'epic'
      },
      
      // إنجازات يومية
      {
        id: 'daily_7',
        title: 'مستخدم أسبوعي',
        description: 'استخدم التطبيق لمدة 7 أيام',
        icon: <Calendar className="w-6 h-6" />,
        requirement: 7,
        currentProgress: daysActive,
        reward: 500,
        category: 'daily',
        completed: daysActive >= 7,
        rarity: 'common'
      },
      {
        id: 'daily_30',
        title: 'مستخدم شهري',
        description: 'استخدم التطبيق لمدة 30 يوم',
        icon: <Calendar className="w-6 h-6" />,
        requirement: 30,
        currentProgress: daysActive,
        reward: 2000,
        category: 'daily',
        completed: daysActive >= 30,
        rarity: 'rare'
      },
      {
        id: 'daily_100',
        title: 'مستخدم مخضرم',
        description: 'استخدم التطبيق لمدة 100 يوم',
        icon: <Crown className="w-6 h-6" />,
        requirement: 100,
        currentProgress: daysActive,
        reward: 10000,
        category: 'daily',
        completed: daysActive >= 100,
        rarity: 'legendary'
      }
    ];

    setAchievements(achievementsList);
  };

  const claimReward = (achievement: Achievement) => {
    if (!achievement.completed) return;
    
    const claimedKey = `achievement_${achievement.id}_claimed`;
    if (localStorage.getItem(claimedKey)) return;

    const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
    const newPoints = currentPoints + achievement.reward;
    localStorage.setItem('pointsBalance', newPoints.toString());
    localStorage.setItem(claimedKey, 'true');

    // إعادة تحميل الإنجازات
    loadAchievements();
  };

  const isRewardClaimed = (achievementId: string) => {
    return !!localStorage.getItem(`achievement_${achievementId}_claimed`);
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'from-gray-500 to-gray-600';
      case 'rare': return 'from-blue-500 to-blue-600';
      case 'epic': return 'from-purple-500 to-purple-600';
      case 'legendary': return 'from-yellow-500 to-orange-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const filteredAchievements = filter === 'all' 
    ? achievements 
    : achievements.filter(a => a.category === filter);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-white">الإنجازات المتقدمة</h1>
      </div>

      {/* Filter Buttons */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {[
          { key: 'all', label: 'الكل' },
          { key: 'ads', label: 'الإعلانات' },
          { key: 'points', label: 'النقاط' },
          { key: 'referrals', label: 'الإحالات' },
          { key: 'daily', label: 'يومية' }
        ].map((category) => (
          <Button
            key={category.key}
            variant={filter === category.key ? "default" : "ghost"}
            size="sm"
            onClick={() => setFilter(category.key)}
            className={`whitespace-nowrap ${filter === category.key ? 'bg-white text-black' : 'text-white hover:bg-white/20'}`}
          >
            {category.label}
          </Button>
        ))}
      </div>

      {/* Achievements Grid */}
      <div className="space-y-4">
        {filteredAchievements.map((achievement) => {
          const progress = Math.min((achievement.currentProgress / achievement.requirement) * 100, 100);
          const claimed = isRewardClaimed(achievement.id);
          
          return (
            <div
              key={achievement.id}
              className={`bg-gradient-to-r ${getRarityColor(achievement.rarity)} rounded-xl p-4 border border-white/20 ${achievement.completed ? 'shadow-lg' : 'opacity-70'}`}
            >
              <div className="flex items-start gap-4">
                <div className="text-white">
                  {achievement.icon}
                </div>
                
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-white font-bold text-lg">{achievement.title}</h3>
                      <p className="text-white/80 text-sm">{achievement.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="bg-white/20 rounded-full px-3 py-1">
                        <span className="text-white text-sm font-bold">
                          +{achievement.reward} نقطة
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-white text-sm">
                      <span>التقدم</span>
                      <span>{achievement.currentProgress}/{achievement.requirement}</span>
                    </div>
                    <Progress value={progress} className="h-2 bg-white/20" />
                  </div>
                  
                  {achievement.completed && (
                    <div className="mt-3">
                      {claimed ? (
                        <div className="bg-green-500/20 text-green-300 px-4 py-2 rounded-lg text-center">
                          ✓ تم استلام المكافأة
                        </div>
                      ) : (
                        <Button
                          onClick={() => claimReward(achievement)}
                          className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold"
                        >
                          <Gift className="w-4 h-4 mr-2" />
                          استلم المكافأة
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default EnhancedAchievements;
