
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { X } from 'lucide-react';

interface PremiumSpinProps {
  onClose: () => void;
  currentPoints: number;
  onReward: (uc: number) => void;
}

const PremiumSpin = ({ onClose, currentPoints, onReward }: PremiumSpinProps) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [userSpinCount, setUserSpinCount] = useState(0);
  const [totalUCWon, setTotalUCWon] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const { toast } = useToast();

  // Fixed rewards that cycle repeatedly - actual winnings
  const fixedRewards = [30, 7, 10, 2, 12];

  // Display values for the wheel - visual only
  const wheelDisplayValues = [10, 12, 30, 25, 70, 325, 660, 7, 5, 1320];

  // Create segments for the wheel using display values
  const segments = wheelDisplayValues.map((value, index) => ({
    label: `${value} UC`,
    value: value,
    color: [
      "#e74c3c", "#3498db", "#2ecc71", "#f39c12", "#9b59b6",
      "#e67e22", "#1abc9c", "#34495e", "#fd79a8", "#a29bfe"
    ][index],
    textColor: "#fff"
  }));

  useEffect(() => {
    // Load data from localStorage
    const savedSpinCount = parseInt(localStorage.getItem('userSpinCount') || '0');
    const savedTotalUC = parseInt(localStorage.getItem('totalUCWon') || '0');
    setUserSpinCount(savedSpinCount);
    setTotalUCWon(savedTotalUC);
  }, []);

  const handleSpin = () => {
    if (currentPoints < 3100) {
      toast({
        title: "❌ نقاط غير كافية للّف",
        description: "تحتاج إلى 3100 نقطة للعب.",
        variant: "destructive"
      });
      return;
    }

    if (isSpinning) return;

    setIsSpinning(true);
    
    // Deduct points first
    const newPointsBalance = currentPoints - 3100;
    localStorage.setItem('pointsBalance', newPointsBalance.toString());
    
    // Get actual reward from cycling fixed rewards
    const ucReward = fixedRewards[userSpinCount % 5];
    
    // Update counters
    const newSpinCount = userSpinCount + 1;
    const newTotalUC = totalUCWon + ucReward;
    
    setUserSpinCount(newSpinCount);
    setTotalUCWon(newTotalUC);
    
    // Save to localStorage
    localStorage.setItem('userSpinCount', newSpinCount.toString());
    localStorage.setItem('totalUCWon', newTotalUC.toString());
    
    // Calculate wheel rotation for visual effect
    const spins = Math.floor(Math.random() * 5) + 8;
    const segmentAngle = 360 / wheelDisplayValues.length; // 36 degrees per segment
    const randomSegmentIndex = Math.floor(Math.random() * wheelDisplayValues.length);
    const finalAngle = randomSegmentIndex * segmentAngle + Math.random() * segmentAngle;
    const totalRotation = rotation + (360 * spins) + finalAngle;
    
    setRotation(totalRotation);

    // Show confetti effect
    setShowConfetti(true);
    
    setTimeout(() => {
      setShowConfetti(false);
    }, 3000);

    setTimeout(() => {
      setIsSpinning(false);
      onReward(ucReward);
      
      // Vibration effect
      if (navigator.vibrate) {
        navigator.vibrate([200, 100, 600]);
      }
      
      toast({
        title: "🎉 مبروك! لقد ربحت!",
        description: `فزت بـ ${ucReward} شدة! تم خصم 3100 نقطة. إجمالي شداتك: ${newTotalUC}`
      });

      setTimeout(() => {
        onClose();
      }, 2500);
    }, 4500);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-sm mx-auto bg-gradient-to-br from-[#fff6e5] to-[#ffe4c4] relative overflow-hidden border-0 shadow-2xl fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 max-h-screen" dir="rtl">
        {/* Confetti Effect */}
        {showConfetti && (
          <div className="absolute inset-0 pointer-events-none z-50">
            {[...Array(80)].map((_, i) => (
              <div
                key={i}
                className="absolute w-3 h-3 animate-bounce"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  backgroundColor: ['#FFD700', '#FF5722', '#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#00BCD4', '#E91E63'][Math.floor(Math.random() * 8)],
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${1 + Math.random() * 2}s`,
                  borderRadius: ['50%', '0%'][Math.floor(Math.random() * 2)],
                  transform: `rotate(${Math.random() * 360}deg)`
                }}
              />
            ))}
          </div>
        )}

        <DialogHeader className="pb-2 pt-2">
          <DialogTitle className="text-center text-xl font-bold bg-gradient-to-r from-[#f54c1e] to-[#ff7a00] bg-clip-text text-transparent">
            🎯 السحب المميز
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute left-4 top-4 hover:bg-white/30 rounded-full"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>
        
        <div className="flex flex-col items-center justify-center space-y-3 p-3 pb-4 overflow-y-auto">
          {/* Subtitle */}
          <div className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-2 w-full border border-blue-100">
            <p className="text-xs text-[#5e5e5e] font-medium">
              🌀 اسحب واربح شدات ببجي مجاناً!
            </p>
            <p className="text-xs text-gray-500 mt-1">
              💰 إجمالي شداتك المكتسبة: {totalUCWon} UC
            </p>
          </div>

          {/* Motivational Text */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-3 shadow-lg">
              <p className="text-lg font-bold text-white mb-1">
                ✨ استعد للفوز الكبير! ✨
              </p>
              <p className="text-sm text-purple-100">
                🎊 حظك اليوم رائع، اسحب الآن! 🎊
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 bg-white/70 rounded-full px-3 py-1 backdrop-blur-sm mt-2">
              <span className="text-xs font-medium text-gray-700">🎮 دورة رقم:</span>
              <span className="text-sm font-bold text-[#4CAF50]">{userSpinCount + 1}</span>
            </div>
          </div>

          {/* Spinning Wheel */}
          <div className="relative flex items-center justify-center">
            {/* Pointer Arrow */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-3 z-10">
              <div className="w-0 h-0 border-l-6 border-r-6 border-b-8 border-l-transparent border-r-transparent border-b-[#FF522E] drop-shadow-lg"></div>
            </div>
            
            {/* Wheel Container */}
            <div className="relative">
              <div 
                className={`w-40 h-40 rounded-full border-4 border-[#FF7D00] shadow-2xl transition-transform ease-out ${isSpinning ? 'duration-[4500ms]' : 'duration-300'} bg-gradient-to-br from-yellow-100 to-orange-100`}
                style={{ transform: `rotate(${rotation}deg)` }}
              >
                {/* Wheel Segments */}
                <svg viewBox="0 0 200 200" className="w-full h-full">
                  {segments.map((segment, index) => {
                    const angle = (360 / segments.length) * index;
                    const nextAngle = (360 / segments.length) * (index + 1);
                    
                    const startAngle = (angle * Math.PI) / 180;
                    const endAngle = (nextAngle * Math.PI) / 180;
                    
                    const x1 = 100 + 85 * Math.cos(startAngle);
                    const y1 = 100 + 85 * Math.sin(startAngle);
                    const x2 = 100 + 85 * Math.cos(endAngle);
                    const y2 = 100 + 85 * Math.sin(endAngle);
                    
                    const largeArcFlag = (nextAngle - angle) > 180 ? 1 : 0;
                    const pathData = `M 100 100 L ${x1} ${y1} A 85 85 0 ${largeArcFlag} 1 ${x2} ${y2} Z`;
                    
                    const textAngle = (startAngle + endAngle) / 2;
                    const textX = 100 + 55 * Math.cos(textAngle);
                    const textY = 100 + 55 * Math.sin(textAngle);
                    
                    return (
                      <g key={index}>
                        <path
                          d={pathData}
                          fill={segment.color}
                          stroke="#FF7D00"
                          strokeWidth="2"
                        />
                        <text
                          x={textX}
                          y={textY}
                          textAnchor="middle"
                          dominantBaseline="central"
                          fill={segment.textColor}
                          fontSize="9"
                          fontWeight="bold"
                          className="pointer-events-none"
                        >
                          {segment.label}
                        </text>
                      </g>
                    );
                  })}
                </svg>
                
                {/* Center Circle */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-gradient-to-br from-[#FF7D00] to-[#FF522E] rounded-full border-4 border-white shadow-xl flex items-center justify-center">
                  <span className="text-white font-bold text-xs">UC</span>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="text-center space-y-1 bg-white/50 rounded-xl p-2 w-full backdrop-blur-sm">
            <p className="text-xs text-gray-600">💸 التكلفة: 3,100 نقطة | 🔢 نقاطك: {currentPoints.toLocaleString()}</p>
            <p className="text-xs font-medium text-green-600">🎯 مرات اللعب: {userSpinCount}</p>
          </div>

          {/* Spin Button */}
          <Button
            onClick={handleSpin}
            disabled={currentPoints < 3100 || isSpinning}
            className="w-full bg-gradient-to-r from-[#FF522E] to-[#e03e1a] hover:from-[#e03e1a] hover:to-[#c62d0f] text-white font-bold py-3 text-sm rounded-xl shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          >
            {isSpinning ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                🌀 جاري الدوران...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                🎡 اسحب للحصول على الجائزة
                <span className="text-yellow-300">✨</span>
              </div>
            )}
          </Button>

          {/* Back Button */}
          <Button
            onClick={onClose}
            variant="outline"
            className="w-full bg-gradient-to-r from-gray-100 to-gray-200 hover:from-gray-200 hover:to-gray-300 text-gray-700 border-gray-300 rounded-xl py-2 shadow-lg"
          >
            ⬅ العودة للرئيسية
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PremiumSpin;
