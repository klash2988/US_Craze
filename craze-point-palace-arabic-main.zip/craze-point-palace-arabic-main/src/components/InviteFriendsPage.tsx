
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  ArrowRight, 
  Users, 
  Gift, 
  Copy, 
  Share, 
  Star,
  Trophy,
  Coins,
  CheckCircle,
  UserPlus,
  Heart,
  Sparkles,
  Crown
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/hooks/useLanguage';

interface InviteFriendsPageProps {
  onBack: () => void;
}

const InviteFriendsPage = ({ onBack }: InviteFriendsPageProps) => {
  const [inviteCode] = useState(() => localStorage.getItem('userId') || localStorage.getItem('userCode') || 'UC123456');
  const [friendsInvited, setFriendsInvited] = useState(() => parseInt(localStorage.getItem('friendsInvited') || '0'));
  const { toast } = useToast();
  const { language } = useLanguage();

  const inviteLink = `https://uccraze.app/invite/${inviteCode}`;

  const rewards = [
    {
      friends: 1,
      reward: '500 نقطة',
      icon: <Coins className="w-6 h-6" />,
      color: 'from-blue-500 to-blue-600',
      achieved: friendsInvited >= 1
    },
    {
      friends: 3,
      reward: '20 شدة',
      icon: <Gift className="w-6 h-6" />,
      color: 'from-green-500 to-green-600',
      achieved: friendsInvited >= 3
    },
    {
      friends: 5,
      reward: '50 شدة',
      icon: <Star className="w-6 h-6" />,
      color: 'from-yellow-500 to-yellow-600',
      achieved: friendsInvited >= 5
    },
    {
      friends: 10,
      reward: '100 شدة',
      icon: <Trophy className="w-6 h-6" />,
      color: 'from-purple-500 to-purple-600',
      achieved: friendsInvited >= 10
    },
    {
      friends: 20,
      reward: '200 شدة + لقب مميز',
      icon: <Crown className="w-6 h-6" />,
      color: 'from-amber-500 to-orange-600',
      achieved: friendsInvited >= 20
    }
  ];

  const copyInviteCode = () => {
    navigator.clipboard.writeText(inviteCode);
    toast({
      title: "تم النسخ! 📋",
      description: "تم نسخ كود الدعوة"
    });
  };

  const shareInviteLink = () => {
    const shareText = `🎮 انضم إلي في UC Craze واحصل على شدات مجانية!\n\n🎁 استخدم كود الدعوة: ${inviteCode}\n\n${inviteLink}`;
    
    if (navigator.share) {
      navigator.share({
        title: 'UC Craze - احصل على شدات مجانية!',
        text: shareText,
        url: inviteLink
      });
    } else {
      navigator.clipboard.writeText(shareText);
      toast({
        title: "تم النسخ! 🔗",
        description: "تم نسخ رابط الدعوة"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-600 p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20 transform hover:scale-110 transition-all duration-300"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <div className="text-center flex-1">
          <h1 className="text-3xl font-bold text-white mb-2">👥 دعوة الأصدقاء</h1>
          <p className="text-white/80 text-sm">ادع أصدقاءك واحصل على مكافآت رائعة!</p>
        </div>
      </div>

      {/* Stats Card */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-indigo-500/20"></div>
        <CardContent className="p-6 relative">
          <div className="text-center">
            <div className="bg-white/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 animate-pulse">
              <Users className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-white text-2xl font-bold mb-2">الأصدقاء المدعوين</h2>
            <div className="text-4xl font-bold text-white mb-2">{friendsInvited}</div>
            <div className="flex items-center justify-center gap-2">
              <Heart className="w-4 h-4 text-red-400 animate-pulse" />
              <span className="text-white/80">شكراً لك على نشر المتعة!</span>
              <Heart className="w-4 h-4 text-red-400 animate-pulse" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invite Code Card */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-center flex items-center justify-center gap-2">
            <Sparkles className="w-5 h-5" />
            كود الدعوة الخاص بك
            <Sparkles className="w-5 h-5" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-white/20 rounded-xl p-4 mb-4 text-center relative">
            <div className="text-white text-2xl font-bold tracking-wider mb-2">{inviteCode}</div>
            <div className="text-white/80 text-sm">شارك هذا الكود مع أصدقائك</div>
            <div className="absolute top-2 right-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={copyInviteCode}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-3 rounded-xl transform hover:scale-105 transition-all duration-300"
            >
              <Copy className="w-5 h-5 ml-2" />
              نسخ الكود
            </Button>
            
            <Button
              onClick={shareInviteLink}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-3 rounded-xl transform hover:scale-105 transition-all duration-300"
            >
              <Share className="w-5 h-5 ml-2" />
              مشاركة الرابط
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Rewards Section */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-center flex items-center justify-center gap-2">
            🎁 مكافآت الدعوة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rewards.map((reward, index) => (
              <div
                key={index}
                className={`relative overflow-hidden rounded-xl p-4 border-2 transition-all duration-300 transform hover:scale-105 ${
                  reward.achieved
                    ? 'bg-gradient-to-r from-green-500/20 to-green-600/20 border-green-400 shadow-lg'
                    : 'bg-white/10 border-white/20 hover:bg-white/20'
                }`}
              >
                {reward.achieved && (
                  <div className="absolute top-2 right-2">
                    <CheckCircle className="w-6 h-6 text-green-400 animate-pulse" />
                  </div>
                )}
                
                <div className="flex items-center gap-4">
                  <div className={`bg-gradient-to-r ${reward.color} rounded-full w-12 h-12 flex items-center justify-center text-white`}>
                    {reward.icon}
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-white font-bold">
                      ادع {reward.friends} {reward.friends === 1 ? 'صديق' : 'أصدقاء'}
                    </div>
                    <div className="text-white/80 text-sm">
                      احصل على: {reward.reward}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    {reward.achieved ? (
                      <div className="text-green-400 font-bold text-sm">✅ مكتمل</div>
                    ) : (
                      <div className="text-white/60 text-sm">
                        {reward.friends - friendsInvited} متبقي
                      </div>
                    )}
                  </div>
                </div>
                
                {reward.achieved && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-pulse"></div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* How it Works */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white text-center">كيف يعمل نظام الدعوة؟</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-500 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold">1</div>
              <div>
                <div className="text-white font-bold text-sm">شارك كود الدعوة</div>
                <div className="text-white/80 text-xs">أرسل الكود لأصدقائك</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="bg-green-500 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold">2</div>
              <div>
                <div className="text-white font-bold text-sm">صديقك ينضم</div>
                <div className="text-white/80 text-xs">يستخدم الكود عند التسجيل</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="bg-purple-500 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold">3</div>
              <div>
                <div className="text-white font-bold text-sm">احصل على المكافأة</div>
                <div className="text-white/80 text-xs">تحصل أنت وصديقك على نقاط مجانية!</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InviteFriendsPage;
