
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowRight, Video, TrendingUp } from 'lucide-react';

interface ContentCreatorPageProps {
  onBack: () => void;
}

const ContentCreatorPage = ({ onBack }: ContentCreatorPageProps) => {
  const [videoLink, setVideoLink] = useState('');
  const [channelId, setChannelId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!videoLink || !channelId) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    const formData = new FormData();
    formData.append('videoLink', videoLink);
    formData.append('channelId', channelId);
    formData.append('_captcha', 'false');
    formData.append('_template', 'table');
    formData.append('_subject', 'طلب صانع محتوى - UC Craze');

    try {
      await fetch('https://formsubmit.co/klash29885@gmail.com', {
        method: 'POST',
        body: formData
      });

      toast({
        title: "تم الإرسال بنجاح! ✅",
        description: "تم إرسال النموذج بنجاح!"
      });

      setTimeout(() => {
        onBack();
      }, 4000);
    } catch (error) {
      toast({
        title: "خطأ في الإرسال",
        description: "حدث خطأ أثناء إرسال النموذج. حاول مرة أخرى.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-4" dir="rtl">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={onBack} className="text-white">
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white mr-4">صانع المحتوى 🎬</h1>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-6">
          <div className="text-center mb-6">
            <Video className="w-16 h-16 mx-auto mb-4 text-white" />
            <h2 className="text-xl font-bold text-white mb-2">كن شريكنا في النجاح!</h2>
            <p className="text-white/90 text-sm leading-relaxed">
              🎬 أنشئ فيديو يشرح التطبيق واذكر اسم "UC Craze"
            </p>
          </div>

          <div className="bg-white/20 rounded-lg p-4 mb-6 text-center">
            <TrendingUp className="w-8 h-8 mx-auto mb-2 text-yellow-300" />
            <p className="text-white font-bold">
              📈 ستحصل على 60 شدة لكل 1000 مشاهدة
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="videoLink" className="text-white">رابط الفيديو *</Label>
              <Input
                id="videoLink"
                value={videoLink}
                onChange={(e) => setVideoLink(e.target.value)}
                placeholder="https://youtube.com/watch?v=..."
                required
                className="bg-white/20 border-white/30 text-white placeholder:text-white/70"
              />
            </div>

            <div>
              <Label htmlFor="channelId" className="text-white">معرف القناة *</Label>
              <Input
                id="channelId"
                value={channelId}
                onChange={(e) => setChannelId(e.target.value)}
                placeholder="@channel_name أو رابط القناة"
                required
                className="bg-white/20 border-white/30 text-white placeholder:text-white/70"
              />
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold py-3"
            >
              {isSubmitting ? 'جاري الإرسال...' : 'إرسال الطلب 🚀'}
            </Button>
          </form>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
          <h3 className="font-bold text-white mb-2">الشروط:</h3>
          <ul className="text-sm text-white/90 space-y-1">
            <li>• يجب ذكر اسم "UC Craze" في الفيديو</li>
            <li>• يتم احتساب المشاهدات كل أسبوع</li>
            <li>• الحد الأدنى 1000 مشاهدة للحصول على المكافأة</li>
            <li>• يجب أن يكون المحتوى أصلي وغير مخالف</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ContentCreatorPage;
