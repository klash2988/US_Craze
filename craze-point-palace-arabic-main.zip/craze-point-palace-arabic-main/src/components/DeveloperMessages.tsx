
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { MessageCircle, Send, X, Plus } from 'lucide-react';

interface DeveloperMessage {
  id: string;
  title: string;
  message: string;
  targetUserCode: string;
  timestamp: Date;
  isRead: boolean;
}

const DeveloperMessages = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<DeveloperMessage[]>([]);
  const [newMessage, setNewMessage] = useState({
    title: '',
    message: '',
    targetUserCode: ''
  });
  const [isComposing, setIsComposing] = useState(false);
  const { toast } = useToast();

  const currentUserCode = localStorage.getItem('userCode') || '';

  useEffect(() => {
    // Load messages from localStorage
    const storedMessages = localStorage.getItem('developerMessages');
    if (storedMessages) {
      const parsed = JSON.parse(storedMessages);
      setMessages(parsed.map((msg: any) => ({
        ...msg,
        timestamp: new Date(msg.timestamp)
      })));
    }
  }, []);

  useEffect(() => {
    // Save messages to localStorage
    if (messages.length > 0) {
      localStorage.setItem('developerMessages', JSON.stringify(messages));
    }
  }, [messages]);

  const userMessages = messages.filter(msg => 
    msg.targetUserCode === currentUserCode || msg.targetUserCode === 'ALL'
  );

  const unreadCount = userMessages.filter(msg => !msg.isRead).length;

  const handleSendMessage = () => {
    if (!newMessage.title || !newMessage.message || !newMessage.targetUserCode) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول",
        variant: "destructive"
      });
      return;
    }

    const message: DeveloperMessage = {
      id: Date.now().toString(),
      title: newMessage.title,
      message: newMessage.message,
      targetUserCode: newMessage.targetUserCode,
      timestamp: new Date(),
      isRead: false
    };

    setMessages(prev => [...prev, message]);
    setNewMessage({ title: '', message: '', targetUserCode: '' });
    setIsComposing(false);

    toast({
      title: "✅ تم إرسال الرسالة",
      description: "تم إرسال الرسالة بنجاح للمستخدم"
    });
  };

  const markAsRead = (messageId: string) => {
    setMessages(prev => 
      prev.map(msg => 
        msg.id === messageId ? { ...msg, isRead: true } : msg
      )
    );
  };

  const isDeveloper = currentUserCode === 'DEV123'; // كود المطور الخاص

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="relative bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg"
        size="sm"
      >
        <MessageCircle className="w-4 h-4 ml-2" />
        رسائل المطور
        {unreadCount > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
            {unreadCount}
          </span>
        )}
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md mx-auto max-h-[80vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-bold">
              💬 رسائل المطور
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="absolute left-4 top-4"
            >
              <X className="w-4 h-4" />
            </Button>
          </DialogHeader>
          
          <div className="p-4">
            {/* Developer Panel */}
            {isDeveloper && (
              <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold text-blue-800">🔧 لوحة المطور</h3>
                  <Button
                    onClick={() => setIsComposing(!isComposing)}
                    size="sm"
                    className="bg-blue-500 hover:bg-blue-600"
                  >
                    <Plus className="w-4 h-4 ml-1" />
                    رسالة جديدة
                  </Button>
                </div>

                {isComposing && (
                  <div className="space-y-3 mt-3">
                    <Input
                      placeholder="عنوان الرسالة"
                      value={newMessage.title}
                      onChange={(e) => setNewMessage(prev => ({ ...prev, title: e.target.value }))}
                    />
                    <Input
                      placeholder="كود المستخدم (أو ALL للجميع)"
                      value={newMessage.targetUserCode}
                      onChange={(e) => setNewMessage(prev => ({ ...prev, targetUserCode: e.target.value }))}
                    />
                    <Textarea
                      placeholder="نص الرسالة..."
                      value={newMessage.message}
                      onChange={(e) => setNewMessage(prev => ({ ...prev, message: e.target.value }))}
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleSendMessage} size="sm" className="flex-1">
                        <Send className="w-4 h-4 ml-1" />
                        إرسال
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setIsComposing(false)}
                        size="sm"
                      >
                        إلغاء
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Messages List */}
            <div className="space-y-3">
              {userMessages.length === 0 ? (
                <div className="text-center p-6 text-gray-500">
                  📭 لا توجد رسائل حالياً
                </div>
              ) : (
                userMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`p-3 rounded-lg border-r-4 ${
                      message.isRead 
                        ? 'bg-gray-50 border-gray-300' 
                        : 'bg-blue-50 border-blue-500'
                    }`}
                    onClick={() => !message.isRead && markAsRead(message.id)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-gray-800">{message.title}</h4>
                      {!message.isRead && (
                        <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                          جديد
                        </span>
                      )}
                    </div>
                    <p className="text-gray-700 text-sm leading-relaxed">
                      {message.message}
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      {message.timestamp.toLocaleString('ar-SA')}
                    </p>
                  </div>
                ))
              )}
            </div>

            {/* User Info */}
            <div className="mt-4 p-2 bg-gray-100 rounded text-center">
              <p className="text-xs text-gray-600">
                كود المستخدم: <span className="font-mono font-bold">{currentUserCode}</span>
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DeveloperMessages;
