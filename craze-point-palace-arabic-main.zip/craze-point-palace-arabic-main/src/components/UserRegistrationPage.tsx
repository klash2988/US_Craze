import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { User, Sparkles, Crown } from 'lucide-react';

interface UserRegistrationPageProps {
  onComplete: (userData: { name: string; userId: string }) => void;
}

const UserRegistrationPage = ({ onComplete }: UserRegistrationPageProps) => {
  const [userName, setUserName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const generateUserId = () => {
    const timestamp = Date.now().toString();
    const random = Math.random().toString(36).substr(2, 9);
    return `UC${timestamp.slice(-6)}${random.toUpperCase()}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userName.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسمك",
        variant: "destructive"
      });
      return;
    }

    if (userName.trim().length < 2) {
      toast({
        title: "خطأ",
        description: "الاسم يجب أن يكون أكثر من حرف واحد",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    // Generate unique user ID
    const userId = generateUserId();
    
    // Save user data to localStorage
    const userData = {
      name: userName.trim(),
      userId: userId,
      registrationDate: new Date().toISOString()
    };

    localStorage.setItem('userName', userData.name);
    localStorage.setItem('userId', userData.userId);
    localStorage.setItem('userRegistrationDate', userData.registrationDate);
    
    // Also keep the old userCode for backward compatibility
    localStorage.setItem('userCode', userData.userId);

    toast({
      title: "🎉 مرحباً بك!",
      description: `تم تسجيلك بنجاح. معرفك: ${userId}`
    });

    setTimeout(() => {
      onComplete(userData);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4" dir="rtl">
      <Card className="w-full max-w-md bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-20 h-20 bg-gradient-to-r from-orange-500 to-yellow-500 rounded-full flex items-center justify-center">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-white mb-2">
            🎮 مرحباً بك في UC Craze
          </CardTitle>
          <p className="text-white/80 text-sm">
            أدخل اسمك للبدء في جمع النقاط والفوز بالشدات!
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-white text-sm font-medium">
                ما اسمك؟ *
              </label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                <Input
                  type="text"
                  placeholder="أدخل اسمك هنا"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="bg-white/20 border-white/30 text-white placeholder:text-white/50 pr-12"
                  maxLength={20}
                  required
                />
              </div>
              <p className="text-white/60 text-xs">
                سيتم استخدام هذا الاسم لمناداتك في التطبيق
              </p>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white font-bold py-3 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200"
            >
              {isSubmitting ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  جاري التسجيل...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  🚀 ابدأ رحلتك الآن
                </>
              )}
            </Button>
          </form>

          <div className="text-center">
            <p className="text-white/60 text-xs">
              ✨ ستحصل على معرف فريد خاص بك للاستفادة من جميع المزايا
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserRegistrationPage;
