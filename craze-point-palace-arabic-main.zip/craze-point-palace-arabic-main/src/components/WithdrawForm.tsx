import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { X } from 'lucide-react';

interface WithdrawFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

const WithdrawForm = ({ onClose, onSuccess }: WithdrawFormProps) => {
  const [pubgId, setPubgId] = useState('');
  const [ucType, setUcType] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const userCode = localStorage.getItem('userCode') || '';
  const totalUC = parseInt(localStorage.getItem('totalUCWon') || '0');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!pubgId || !ucType) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    const formData = new FormData();
    formData.append('pubgId', pubgId);
    formData.append('ucType', ucType);
    formData.append('userCode', userCode);
    formData.append('notes', notes);
    formData.append('_captcha', 'false');
    formData.append('_template', 'table');

    try {
      await fetch('https://formsubmit.co/klash29885@gmail.com', {
        method: 'POST',
        body: formData
      });

      toast({
        title: "تم الإرسال بنجاح! ✅",
        description: "تم إرسال طلبك بنجاح! سيتم التواصل معك خلال 24 ساعة."
      });

      onSuccess();
    } catch (error) {
      toast({
        title: "خطأ في الإرسال",
        description: "حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">سحب الشدات 💰</DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute left-4 top-4"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>
        
        <div className="p-4">
          <div className="text-center mb-4">
            <p className="text-lg font-bold">رصيدك من الشدات: {totalUC}</p>
          </div>

          {totalUC >= 60 ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="pubgId">معرف PUBG *</Label>
                <Input
                  id="pubgId"
                  value={pubgId}
                  onChange={(e) => setPubgId(e.target.value)}
                  placeholder="أدخل معرف PUBG الخاص بك"
                  required
                />
              </div>

              <div>
                <Label htmlFor="ucType">نوع الشدات *</Label>
                <Select value={ucType} onValueChange={setUcType} required>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر نوع الشدات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="60 UC">60 UC</SelectItem>
                    <SelectItem value="325 UC">325 UC</SelectItem>
                    <SelectItem value="660 UC">660 UC</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="userCode">كود المستخدم</Label>
                <Input
                  id="userCode"
                  value={userCode}
                  readOnly
                  className="bg-gray-100"
                />
              </div>

              <div>
                <Label htmlFor="notes">ملاحظات (اختياري)</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أي ملاحظات إضافية..."
                  rows={3}
                />
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
              >
                {isSubmitting ? 'جاري الإرسال...' : '📤 إرسال الطلب'}
              </Button>
            </form>
          ) : (
            <div className="text-center p-6">
              <p className="text-lg text-orange-600 font-semibold">
                ⚠️ لا تملك شدات كافية للسحب. اربح شدات من العجلة المميزة أولاً.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WithdrawForm;
