
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface AboutAppPageProps {
  onBack: () => void;
}

const AboutAppPage = ({ onBack }: AboutAppPageProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-yellow-400 to-orange-500 p-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-white">ℹ️ حول التطبيق</h1>
      </div>

      {/* Content */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mx-auto max-w-md shadow-lg">
        <div className="text-center space-y-4 text-gray-800 leading-relaxed">
          <p className="text-lg">
            🎮 تطبيق UC Craze هو تطبيق مجاني يتيح لك ربح شدات ببجي من خلال مشاهدة الإعلانات وإكمال المهام ودعوة الأصدقاء.
          </p>
          <p className="text-red-600 font-semibold">
            ❌ هذا التطبيق غير تابع رسميًا لشركة PUBG أو Tencent.
          </p>
          <p className="text-blue-600">
            💡 تم تطويره من أجل الترفيه فقط.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutAppPage;
