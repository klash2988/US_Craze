
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/hooks/useLanguage';
import { useSounds } from '@/hooks/useSounds';
import { useAdMob } from '@/hooks/useAdMob';
import { 
  Coins, 
  Gift, 
  Star, 
  Trophy, 
  Settings, 
  CircleDollarSign,
  Target,
  TrendingUp,
  MessageCircle,
  Bot,
  Crown,
  Gamepad2,
  Users,
  FileText,
  Zap,
  ChevronDown,
  Code,
  TestTube,
  Video,
  Info,
  Shield,
  ScrollText,
  Play
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import DailySpin from './DailySpin';
import PremiumSpin from './PremiumSpin';
import WithdrawRequestModal from './WithdrawRequestModal';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
  onShowWithdrawForm: () => void;
}

const HomeScreen = ({ onNavigate, onShowWithdrawForm }: HomeScreenProps) => {
  const [pointsBalance, setPointsBalance] = useState(0);
  const [totalUC, setTotalUC] = useState(0);
  const [goldenPoints, setGoldenPoints] = useState(0);
  const [userName, setUserName] = useState('');
  const [userId, setUserId] = useState('');
  const [showDailySpin, setShowDailySpin] = useState(false);
  const [showPremiumSpin, setShowPremiumSpin] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const { toast } = useToast();
  const { language } = useLanguage();
  const { playSound } = useSounds();
  const { showRewardedAd, isLoading, dailyAdsWatched } = useAdMob();

  useEffect(() => {
    const points = parseInt(localStorage.getItem('pointsBalance') || '0');
    const uc = parseInt(localStorage.getItem('totalUCWon') || '0');
    const golden = parseInt(localStorage.getItem('goldenPoints') || '0');
    const name = localStorage.getItem('userName') || 'المستخدم';
    const id = localStorage.getItem('userId') || localStorage.getItem('userCode') || '';
    
    setPointsBalance(points);
    setTotalUC(uc);
    setGoldenPoints(golden);
    setUserName(name);
    setUserId(id);
  }, []);

  const handleSpinSuccess = () => {
    const points = parseInt(localStorage.getItem('pointsBalance') || '0');
    const uc = parseInt(localStorage.getItem('totalUCWon') || '0');
    const golden = parseInt(localStorage.getItem('goldenPoints') || '0');
    setPointsBalance(points);
    setTotalUC(uc);
    setGoldenPoints(golden);
  };

  const handleTestReward = () => {
    const currentPoints = parseInt(localStorage.getItem('pointsBalance') || '0');
    const currentUC = parseInt(localStorage.getItem('totalUCWon') || '0');
    
    const newPoints = currentPoints + 40000;
    const newUC = currentUC + 1000;
    
    localStorage.setItem('pointsBalance', newPoints.toString());
    localStorage.setItem('totalUCWon', newUC.toString());
    
    setPointsBalance(newPoints);
    setTotalUC(newUC);
    
    toast({
      title: "🧪 مكافأة التجربة!",
      description: "تم إضافة 40,000 نقطة و 1,000 شدة للتجربة"
    });
  };

  const handleWatchAd = async () => {
    const success = await showRewardedAd();
    if (success) {
      handleSpinSuccess();
    }
  };

  const remainingAds = Math.max(140 - dailyAdsWatched, 0);

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-300 via-orange-400 to-yellow-500 p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div></div>
        
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white">UC Craze</h1>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={() => onNavigate('settings')}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20 w-8 h-8 p-0"
          >
            <Settings className="w-4 h-4" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20 w-8 h-8 p-0"
              >
                <ChevronDown className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-white shadow-lg border rounded-lg z-50" align="end">
              <DropdownMenuItem onClick={() => onNavigate('userStats')}>
                <TrendingUp className="w-4 h-4 ml-2" />
                إحصائياتي
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleTestReward}>
                <TestTube className="w-4 h-4 ml-2" />
                <span className="text-xs">تجربة (1000 شدة + 40k نقطة)</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => onNavigate('aboutApp')}>
                <Info className="w-4 h-4 ml-2" />
                حول التطبيق
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onNavigate('privacyPolicy')}>
                <Shield className="w-4 h-4 ml-2" />
                سياسة الخصوصية
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onNavigate('terms')}>
                <ScrollText className="w-4 h-4 ml-2" />
                شروط الاستخدام
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* User Info Card */}
      <div className="bg-orange-200/80 backdrop-blur-sm rounded-2xl p-4 mb-6 relative">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-orange-800 text-sm">مرحباً</p>
            <p className="text-orange-900 font-bold">{userName}</p>
            <p className="text-orange-700 text-xs">معرفك: {userId}</p>
          </div>
          <div className="bg-orange-400 rounded-full w-12 h-12 flex items-center justify-center text-white font-bold text-xl">
            {userName.charAt(0).toUpperCase()}
          </div>
        </div>
      </div>

      {/* Balance Section */}
      <div className="flex justify-center gap-3 mb-6 flex-wrap">
        <div className="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2">
          <div className="bg-blue-500 rounded-full w-6 h-6 flex items-center justify-center">
            <Coins className="w-4 h-4 text-white" />
          </div>
          <span className="text-white font-bold text-sm">{pointsBalance.toLocaleString()} نقطة</span>
        </div>
        
        <div className="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2">
          <div className="bg-yellow-500 rounded-full w-6 h-6 flex items-center justify-center overflow-hidden">
            <img 
              src="/lovable-uploads/3a6ec3fa-7669-4be4-80e9-8375660d167d.png" 
              alt="UC" 
              className="w-5 h-5 object-contain"
            />
          </div>
          <span className="text-white font-bold text-sm">{totalUC} شدة</span>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2">
          <div className="bg-amber-500 rounded-full w-6 h-6 flex items-center justify-center">
            <span className="text-white text-lg">🏅</span>
          </div>
          <span className="text-white font-bold text-sm">{goldenPoints.toLocaleString()} ذهبية</span>
        </div>
      </div>

      {/* Withdraw Button */}
      <div className="flex justify-center mb-6">
        <Button
          onClick={() => setShowWithdrawModal(true)}
          className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-8 py-3 rounded-2xl shadow-lg font-bold"
        >
          🔥 طلب سحب الشدات
        </Button>
      </div>

      {/* Content Creator Button */}
      <div className="flex justify-center mb-6">
        <Button
          onClick={() => onNavigate('contentCreator')}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-4 rounded-3xl shadow-2xl font-bold transform hover:scale-105 transition-all duration-300 border-2 border-indigo-300/30 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-pulse"></div>
          <div className="relative flex items-center gap-3">
            <div className="bg-white/20 rounded-full p-2">
              <Video className="w-6 h-6" />
            </div>
            <div className="text-center">
              <div className="text-lg font-extrabold">🎥 هل أنت صانع محتوى؟</div>
              <div className="text-xs opacity-90">Content Creator</div>
            </div>
            <div className="bg-yellow-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">
              مميز
            </div>
          </div>
        </Button>
      </div>

      {/* Developer Messages Button - Special Design */}
      <div className="flex justify-center mb-6">
        <Button
          onClick={() => onNavigate('developerMessages')}
          className="bg-gradient-to-r from-purple-900 via-purple-700 to-blue-900 hover:from-purple-800 hover:via-purple-600 hover:to-blue-800 text-white px-8 py-4 rounded-3xl shadow-2xl font-bold transform hover:scale-105 transition-all duration-300 border-2 border-purple-300/30 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-pulse"></div>
          <div className="relative flex items-center gap-3">
            <div className="bg-white/20 rounded-full p-2">
              <Code className="w-6 h-6" />
            </div>
            <div className="text-center">
              <div className="text-lg font-extrabold">💻 رسائل المطور</div>
              <div className="text-xs opacity-90">Developer Messages</div>
            </div>
            <div className="bg-red-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">
              جديد
            </div>
          </div>
        </Button>
      </div>

      {/* Main Action Buttons Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Daily Spin */}
        <Button
          onClick={() => setShowDailySpin(true)}
          className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white h-20 rounded-2xl shadow-lg flex flex-col items-center justify-center"
        >
          <Target className="w-6 h-6 mb-1" />
          <span className="font-bold text-sm">العجلة اليومية</span>
          <span className="text-xs opacity-90">مجاني</span>
        </Button>

        {/* Enhanced Watch Ads Button */}
        <Button
          onClick={handleWatchAd}
          disabled={isLoading || dailyAdsWatched >= 140}
          className={`bg-gradient-to-r ${dailyAdsWatched >= 140 ? 'from-gray-400 to-gray-500' : 'from-emerald-400 via-green-500 to-teal-600'} hover:${dailyAdsWatched >= 140 ? 'from-gray-500 to-gray-600' : 'from-emerald-500 hover:via-green-600 hover:to-teal-700'} text-white h-20 rounded-2xl shadow-2xl flex flex-col items-center justify-center relative overflow-hidden border-2 ${dailyAdsWatched >= 140 ? 'border-gray-300/50' : 'border-emerald-300/50'} transform hover:scale-105 transition-all duration-300`}
        >
          {/* Animated background */}
          {dailyAdsWatched < 140 && (
            <>
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-transparent to-yellow-400/20 animate-pulse"></div>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse delay-300"></div>
              
              {/* Sparkle effects */}
              <div className="absolute top-1 right-1 w-2 h-2 bg-yellow-300 rounded-full animate-ping"></div>
              <div className="absolute bottom-1 left-1 w-1.5 h-1.5 bg-white rounded-full animate-ping delay-700"></div>
              <div className="absolute top-3 left-3 w-1 h-1 bg-emerald-200 rounded-full animate-ping delay-1000"></div>
            </>
          )}
          
          {/* Main content */}
          <div className="relative z-10 flex flex-col items-center">
            <div className={`${dailyAdsWatched >= 140 ? 'bg-gray-600/20' : 'bg-white/20'} rounded-full p-1.5 mb-1 ${dailyAdsWatched < 140 ? 'animate-bounce' : ''}`}>
              <Play className="w-5 h-5 text-white drop-shadow-lg" />
            </div>
            <span className="font-extrabold text-sm drop-shadow-lg">
              {dailyAdsWatched >= 140 ? 'انتهى اليوم 🔒' : isLoading ? 'جاري التحميل...' : '🎬 شاهد الإعلان'}
            </span>
            <span className="text-xs opacity-90 font-bold">
              {dailyAdsWatched >= 140 ? 'غداً المزيد!' : `${remainingAds} متبقي 🏅`}
            </span>
          </div>
          
          {/* Glow effect */}
          {dailyAdsWatched < 140 && (
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/30 to-teal-600/30 blur-sm"></div>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Tasks Center */}
        <Button
          onClick={() => onNavigate('tasks')}
          className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white h-20 rounded-2xl shadow-lg flex flex-col items-center justify-center"
        >
          <Trophy className="w-6 h-6 mb-1" />
          <span className="font-bold text-sm">مركز المهام</span>
          <span className="text-xs opacity-90">مكافآت رائعة</span>
        </Button>

        {/* Premium Spin */}
        <Button
          onClick={() => setShowPremiumSpin(true)}
          className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white h-20 rounded-2xl shadow-lg flex flex-col items-center justify-center"
        >
          <Crown className="w-6 h-6 mb-1" />
          <span className="font-bold text-sm">العجلة المميزة</span>
          <span className="text-xs opacity-90">3100 نقطة</span>
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Invite Friends - Enhanced with animations */}
        <Button
          onClick={() => onNavigate('inviteFriends')}
          className="bg-gradient-to-r from-pink-500 via-rose-500 to-pink-600 hover:from-pink-600 hover:via-rose-600 hover:to-pink-700 text-white h-20 rounded-2xl shadow-2xl flex flex-col items-center justify-center relative overflow-hidden border-2 border-pink-300/30 transform hover:scale-105 transition-all duration-300"
        >
          {/* Animated background effects */}
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-transparent to-yellow-400/20 animate-pulse"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse delay-500"></div>
          
          {/* Sparkle effects */}
          <div className="absolute top-1 right-1 w-2 h-2 bg-yellow-300 rounded-full animate-ping"></div>
          <div className="absolute bottom-1 left-1 w-1.5 h-1.5 bg-white rounded-full animate-ping delay-1000"></div>
          <div className="absolute top-3 left-3 w-1 h-1 bg-pink-200 rounded-full animate-ping delay-700"></div>
          
          <div className="relative z-10 flex flex-col items-center">
            <div className="bg-white/20 rounded-full p-1.5 mb-1 animate-bounce">
              <Users className="w-5 h-5 text-white drop-shadow-lg" />
            </div>
            <span className="font-extrabold text-sm drop-shadow-lg">دعوة الأصدقاء</span>
            <span className="text-xs opacity-90 font-bold">500 نقطة 🎁</span>
          </div>
          
          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-pink-400/30 to-rose-600/30 blur-sm"></div>
        </Button>

        {/* Empty slot for symmetry */}
        <div></div>
      </div>

      {/* Support Button */}
      <div className="flex justify-center mb-6">
        <Button
          onClick={() => onNavigate('support')}
          className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white px-6 py-3 rounded-2xl shadow-lg flex items-center gap-2"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="font-bold">🎧 مركز الدعم الفني</span>
        </Button>
      </div>

      {/* UC League Button */}
      <div className="flex justify-center mb-6">
        <Button
          className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-6 py-3 rounded-2xl shadow-lg flex items-center gap-2"
        >
          <Zap className="w-5 h-5" />
          <span className="font-bold">دوري جنون الشدات</span>
          <span className="text-xs opacity-90">قريباً</span>
        </Button>
      </div>

      {/* Modals */}
      {showDailySpin && (
        <DailySpin
          onClose={() => setShowDailySpin(false)}
          onReward={handleSpinSuccess}
        />
      )}

      {showPremiumSpin && (
        <PremiumSpin
          onClose={() => setShowPremiumSpin(false)}
          currentPoints={pointsBalance}
          onReward={handleSpinSuccess}
        />
      )}

      {showWithdrawModal && (
        <WithdrawRequestModal
          isOpen={showWithdrawModal}
          onClose={() => setShowWithdrawModal(false)}
          onSuccess={() => {
            setShowWithdrawModal(false);
            handleSpinSuccess();
          }}
        />
      )}
    </div>
  );
};

export default HomeScreen;
