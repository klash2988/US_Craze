
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ArrowRight, Trophy, Target, Calendar, TrendingUp, Award, Coins } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';
import { getUserLevel, getNextLevel, getLevelProgress, LEVELS } from '@/utils/levelSystem';

interface UserStatsPageProps {
  onBack: () => void;
}

const UserStatsPage = ({ onBack }: UserStatsPageProps) => {
  const [stats, setStats] = useState({
    totalPoints: 0,
    totalUC: 0,
    totalAdsWatched: 0,
    totalReferrals: 0,
    daysActive: 0,
    joinDate: '',
    weeklyPoints: 0,
    monthlyPoints: 0
  });
  
  const { language, t } = useLanguage();

  useEffect(() => {
    loadUserStats();
  }, []);

  const loadUserStats = () => {
    const totalPoints = parseInt(localStorage.getItem('pointsBalance') || '0') + 
                       parseInt(localStorage.getItem('totalPointsEarned') || '0');
    const totalUC = parseInt(localStorage.getItem('totalUCWon') || '0');
    const totalAdsWatched = parseInt(localStorage.getItem('totalAdsWatched') || '0');
    const totalReferrals = parseInt(localStorage.getItem('totalReferrals') || '0');
    const joinDate = localStorage.getItem('joinDate') || new Date().toISOString();
    
    // حساب الأيام النشطة
    const joinDateObj = new Date(joinDate);
    const today = new Date();
    const daysActive = Math.floor((today.getTime() - joinDateObj.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    
    // محاكاة النقاط الأسبوعية والشهرية
    const weeklyPoints = Math.floor(totalPoints * 0.3);
    const monthlyPoints = Math.floor(totalPoints * 0.8);

    setStats({
      totalPoints,
      totalUC,
      totalAdsWatched,
      totalReferrals,
      daysActive,
      joinDate,
      weeklyPoints,
      monthlyPoints
    });

    // حفظ تاريخ الانضمام إذا لم يكن موجوداً
    if (!localStorage.getItem('joinDate')) {
      localStorage.setItem('joinDate', new Date().toISOString());
    }
  };

  const currentLevel = getUserLevel(stats.totalPoints);
  const nextLevel = getNextLevel(currentLevel);
  const progress = getLevelProgress(stats.totalPoints);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-700 p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-white">إحصائياتي المفصلة</h1>
      </div>

      {/* Level Progress Card */}
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-6 border border-white/20">
        <div className="flex items-center gap-4 mb-4">
          <div 
            className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-xl"
            style={{ backgroundColor: currentLevel.color }}
          >
            {currentLevel.level}
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">{currentLevel.title}</h2>
            <p className="text-white/80">رتبة {currentLevel.rank}</p>
          </div>
        </div>
        
        {nextLevel && (
          <div className="space-y-2">
            <div className="flex justify-between text-white text-sm">
              <span>التقدم للمستوى التالي</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="h-3 bg-white/20" />
            <p className="text-white/80 text-sm">
              تحتاج {nextLevel.minPoints - stats.totalPoints} نقطة للوصول لمستوى "{nextLevel.title}"
            </p>
          </div>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-2">
            <Coins className="w-6 h-6 text-yellow-400" />
            <span className="text-white font-semibold">إجمالي النقاط</span>
          </div>
          <p className="text-2xl font-bold text-yellow-400">{stats.totalPoints.toLocaleString()}</p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-2">
            <img src="/lovable-uploads/3a14d7c9-84e5-415a-938a-7d4ac876f106.png" alt="UC" className="w-6 h-6" />
            <span className="text-white font-semibold">إجمالي الشدات</span>
          </div>
          <p className="text-2xl font-bold text-blue-400">{stats.totalUC}</p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-6 h-6 text-green-400" />
            <span className="text-white font-semibold">الإعلانات المشاهدة</span>
          </div>
          <p className="text-2xl font-bold text-green-400">{stats.totalAdsWatched}</p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-6 h-6 text-orange-400" />
            <span className="text-white font-semibold">الدعوات</span>
          </div>
          <p className="text-2xl font-bold text-orange-400">{stats.totalReferrals}</p>
        </div>
      </div>

      {/* Additional Stats */}
      <div className="space-y-4">
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-3">
            <Calendar className="w-5 h-5 text-blue-300" />
            <span className="text-white font-semibold">معلومات الحساب</span>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-white/60">تاريخ الانضمام</p>
              <p className="text-white font-semibold">{formatDate(stats.joinDate)}</p>
            </div>
            <div>
              <p className="text-white/60">الأيام النشطة</p>
              <p className="text-white font-semibold">{stats.daysActive} يوم</p>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-5 h-5 text-green-300" />
            <span className="text-white font-semibold">إحصائيات الفترة</span>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-white/60">نقاط هذا الأسبوع</p>
              <p className="text-white font-semibold">{stats.weeklyPoints.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-white/60">نقاط هذا الشهر</p>
              <p className="text-white font-semibold">{stats.monthlyPoints.toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* Level Benefits */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-3 mb-3">
            <Award className="w-5 h-5 text-purple-300" />
            <span className="text-white font-semibold">مميزات مستواك الحالي</span>
          </div>
          <div className="space-y-2">
            {currentLevel.benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400"></div>
                <span className="text-white/90 text-sm">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserStatsPage;
