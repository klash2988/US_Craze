
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  MessageCircle, 
  Send, 
  X, 
  Users, 
  Download, 
  Video,
  Mail,
  Copy,
  Check,
  XIcon
} from 'lucide-react';

interface WithdrawRequest {
  id: string;
  userCode: string;
  ucAmount: number;
  gameId: string;
  timestamp: Date;
  status: 'pending' | 'completed' | 'rejected';
}

interface ContentRequest {
  id: string;
  videoLink: string;
  channelId: string;
  timestamp: Date;
  status: 'pending' | 'approved' | 'rejected';
}

interface AdminCommunicationProps {
  isOpen: boolean;
  onClose: () => void;
}

const AdminCommunication = ({ isOpen, onClose }: AdminCommunicationProps) => {
  const [withdrawRequests, setWithdrawRequests] = useState<WithdrawRequest[]>([]);
  const [contentRequests, setContentRequests] = useState<ContentRequest[]>([]);
  const [selectedUserCode, setSelectedUserCode] = useState('');
  const [messageText, setMessageText] = useState('');
  const { toast } = useToast();

  const currentUserCode = localStorage.getItem('userCode') || '';
  const isDeveloper = currentUserCode === 'DEV123';

  useEffect(() => {
    if (!isDeveloper || !isOpen) return;
    
    console.log('Loading admin requests...');
    
    // Load withdraw requests with better error handling
    try {
      const storedWithdraws = localStorage.getItem('withdrawRequests');
      console.log('Stored withdraw requests:', storedWithdraws);
      
      if (storedWithdraws) {
        const parsed = JSON.parse(storedWithdraws);
        console.log('Parsed withdraw requests:', parsed);
        
        const processedRequests = parsed.map((req: any) => ({
          ...req,
          timestamp: req.timestamp ? new Date(req.timestamp) : new Date()
        }));
        
        console.log('Processed withdraw requests:', processedRequests);
        setWithdrawRequests(processedRequests);
      } else {
        console.log('No withdraw requests found');
        setWithdrawRequests([]);
      }
    } catch (error) {
      console.error('Error loading withdraw requests:', error);
      setWithdrawRequests([]);
    }

    // Load content creator requests with better error handling
    try {
      const storedContent = localStorage.getItem('contentRequests');
      console.log('Stored content requests:', storedContent);
      
      if (storedContent) {
        const parsed = JSON.parse(storedContent);
        console.log('Parsed content requests:', parsed);
        
        const processedRequests = parsed.map((req: any) => ({
          ...req,
          timestamp: req.timestamp ? new Date(req.timestamp) : new Date()
        }));
        
        console.log('Processed content requests:', processedRequests);
        setContentRequests(processedRequests);
      } else {
        console.log('No content requests found');
        setContentRequests([]);
      }
    } catch (error) {
      console.error('Error loading content requests:', error);
      setContentRequests([]);
    }
  }, [isDeveloper, isOpen]);

  const approveWithdrawRequest = (requestId: string) => {
    console.log('Approving withdraw request:', requestId);
    
    // Update withdraw requests
    const requests = JSON.parse(localStorage.getItem('withdrawRequests') || '[]');
    const requestIndex = requests.findIndex((req: any) => req.id === requestId);
    
    if (requestIndex !== -1) {
      requests[requestIndex].status = 'completed';
      localStorage.setItem('withdrawRequests', JSON.stringify(requests));
      console.log('Updated withdraw requests:', requests);
      
      // Also update withdraw records
      const records = JSON.parse(localStorage.getItem('withdrawRecords') || '[]');
      const recordIndex = records.findIndex((record: any) => record.id === requestId);
      
      if (recordIndex !== -1) {
        records[recordIndex].status = 'completed';
        localStorage.setItem('withdrawRecords', JSON.stringify(records));
        console.log('Updated withdraw records:', records);
      }
      
      // Send approval message to user
      const userCode = requests[requestIndex].userCode;
      const approvalMessage = 'تم قبول طلبك\n\nفي انتظار الطابور، دورك قريب';
      
      sendDirectMessage(userCode, approvalMessage);
      
      // Reload requests
      const updatedRequests = requests.map((req: any) => ({
        ...req,
        timestamp: req.timestamp ? new Date(req.timestamp) : new Date()
      }));
      setWithdrawRequests(updatedRequests);
      
      toast({
        title: "تم قبول الطلب",
        description: `تم قبول طلب السحب وإرسال رسالة للمستخدم ${userCode}`
      });
    } else {
      console.log('Request not found:', requestId);
      toast({
        title: "خطأ",
        description: "لم يتم العثور على الطلب",
        variant: "destructive"
      });
    }
  };

  const updateWithdrawStatus = (requestId: string, newStatus: 'completed' | 'rejected') => {
    console.log('Updating withdraw status:', requestId, newStatus);
    
    // Update withdraw requests
    const requests = JSON.parse(localStorage.getItem('withdrawRequests') || '[]');
    const requestIndex = requests.findIndex((req: any) => req.id === requestId);
    
    if (requestIndex !== -1) {
      requests[requestIndex].status = newStatus;
      localStorage.setItem('withdrawRequests', JSON.stringify(requests));
      console.log('Updated withdraw requests:', requests);
      
      // Also update withdraw records
      const records = JSON.parse(localStorage.getItem('withdrawRecords') || '[]');
      const recordIndex = records.findIndex((record: any) => record.id === requestId);
      
      if (recordIndex !== -1) {
        records[recordIndex].status = newStatus;
        localStorage.setItem('withdrawRecords', JSON.stringify(records));
        console.log('Updated withdraw records:', records);
      }
      
      // Send notification message to user
      const userCode = requests[requestIndex].userCode;
      const statusMessage = newStatus === 'completed' 
        ? 'تم قبول طلب السحب وسيتم تنفيذه خلال 24 ساعة'
        : 'تم رفض طلب السحب. يرجى التحقق من البيانات المدخلة';
      
      sendDirectMessage(userCode, statusMessage);
      
      // Reload requests
      const updatedRequests = requests.map((req: any) => ({
        ...req,
        timestamp: req.timestamp ? new Date(req.timestamp) : new Date()
      }));
      setWithdrawRequests(updatedRequests);
      
      toast({
        title: "تم تحديث الحالة",
        description: `تم ${newStatus === 'completed' ? 'قبول' : 'رفض'} الطلب وإرسال إشعار للمستخدم`
      });
    } else {
      console.log('Request not found:', requestId);
      toast({
        title: "خطأ",
        description: "لم يتم العثور على الطلب",
        variant: "destructive"
      });
    }
  };

  const sendDirectMessage = async (userCode: string, message: string) => {
    if (!message.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى كتابة رسالة",
        variant: "destructive"
      });
      return;
    }

    console.log('Sending message to user:', userCode, message);

    // Add message to developer messages system
    const newMessage = {
      id: Date.now().toString(),
      title: "رسالة من الإدارة",
      message: message,
      targetUserCode: userCode,
      timestamp: new Date(),
      isRead: false
    };

    const existingMessages = JSON.parse(localStorage.getItem('developerMessages') || '[]');
    existingMessages.push(newMessage);
    localStorage.setItem('developerMessages', JSON.stringify(existingMessages));

    console.log('Message saved:', newMessage);

    toast({
      title: "✅ تم إرسال الرسالة",
      description: `تم إرسال الرسالة للمستخدم ${userCode}`
    });

    setMessageText('');
  };

  const copyUserCode = (userCode: string) => {
    navigator.clipboard.writeText(userCode);
    toast({
      title: "تم النسخ",
      description: "تم نسخ كود المستخدم"
    });
  };

  const composeEmail = (userCode: string, type: 'withdraw' | 'content') => {
    const subject = type === 'withdraw' ? 'بخصوص طلب سحب الشدات' : 'بخصوص طلب صانع المحتوى';
    const body = `مرحباً،\n\nبخصوص طلبك في تطبيق UC Craze...\n\nكود المستخدم: ${userCode}`;
    
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  if (!isDeveloper) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md mx-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-center text-red-600">
              ⚠️ غير مخول
            </DialogTitle>
          </DialogHeader>
          <div className="p-4 text-center">
            <p className="text-gray-600">هذه الصفحة مخصصة للإدارة فقط</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl mx-auto max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">
            📞 إدارة التواصل
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute left-4 top-4"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>
        
        <div className="p-4">
          <Tabs defaultValue="withdraws" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="withdraws">
                <Download className="w-4 h-4 ml-1" />
                طلبات السحب ({withdrawRequests.length})
              </TabsTrigger>
              <TabsTrigger value="content">
                <Video className="w-4 h-4 ml-1" />
                طلبات المحتوى ({contentRequests.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="withdraws" className="space-y-4">
              <div className="bg-blue-50 p-3 rounded-lg">
                <h3 className="font-bold text-blue-800 mb-2">📋 طلبات سحب الشدات</h3>
                <div className="text-sm text-gray-600 mb-3">
                  عدد الطلبات: {withdrawRequests.length}
                </div>
                {withdrawRequests.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">لا توجد طلبات سحب</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {withdrawRequests.map((request) => (
                      <div key={request.id} className="bg-white p-4 rounded-lg border shadow-sm">
                        {/* Request Header */}
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-lg">طلب سحب #{request.id.slice(-4)}</span>
                            <Badge variant={request.status === 'pending' ? 'secondary' : request.status === 'completed' ? 'default' : 'destructive'}>
                              {request.status === 'pending' ? 'قيد المراجعة' : request.status === 'completed' ? 'مكتمل' : 'مرفوض'}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500">
                            {request.timestamp.toLocaleString('ar-SA')}
                          </p>
                        </div>

                        {/* Request Information - Always Displayed */}
                        <div className="bg-gray-50 p-3 rounded-lg mb-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <span className="font-bold text-gray-700">كود المستخدم:</span>
                              <div className="flex items-center gap-2 mt-1">
                                <code className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">
                                  {request.userCode}
                                </code>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => copyUserCode(request.userCode)}
                                  className="h-6 w-6 p-0"
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            <div>
                              <span className="font-bold text-gray-700">مبلغ الشدات:</span>
                              <p className="text-blue-600 font-bold text-lg">{request.ucAmount} شدة</p>
                            </div>
                            <div>
                              <span className="font-bold text-gray-700">معرف اللعبة:</span>
                              <p className="text-green-600 font-mono">{request.gameId}</p>
                            </div>
                            <div>
                              <span className="font-bold text-gray-700">معرف الطلب:</span>
                              <p className="text-gray-600 font-mono text-sm">{request.id}</p>
                            </div>
                          </div>
                        </div>
                        
                        {/* Action Buttons */}
                        <div className="flex gap-2 flex-wrap">
                          {request.status === 'pending' && (
                            <Button
                              size="sm"
                              onClick={() => approveWithdrawRequest(request.id)}
                              className="bg-green-500 hover:bg-green-600 text-white"
                            >
                              <Check className="w-3 h-3 ml-1" />
                              موافقة
                            </Button>
                          )}
                          
                          <Button
                            size="sm"
                            onClick={() => setSelectedUserCode(request.userCode)}
                            className="bg-blue-500 hover:bg-blue-600"
                          >
                            <MessageCircle className="w-3 h-3 ml-1" />
                            رسالة مخصصة
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => composeEmail(request.userCode, 'withdraw')}
                          >
                            <Mail className="w-3 h-3 ml-1" />
                            إيميل
                          </Button>
                          
                          {request.status === 'pending' && (
                            <Button
                              size="sm"
                              onClick={() => updateWithdrawStatus(request.id, 'rejected')}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              <XIcon className="w-3 h-3 ml-1" />
                              رفض
                            </Button>
                          )}
                        </div>

                        {/* Status Messages */}
                        {request.status === 'completed' && (
                          <div className="bg-green-100 border border-green-300 rounded p-3 mt-3">
                            <p className="text-green-800 text-sm">
                              ✅ تمت الموافقة على هذا الطلب وتم إرسال رسالة الطابور للمستخدم
                            </p>
                          </div>
                        )}
                        
                        {request.status === 'rejected' && (
                          <div className="bg-red-100 border border-red-300 rounded p-3 mt-3">
                            <p className="text-red-800 text-sm">
                              ❌ تم رفض هذا الطلب وتم إرسال إشعار للمستخدم
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="content" className="space-y-4">
              <div className="bg-purple-50 p-3 rounded-lg">
                <h3 className="font-bold text-purple-800 mb-2">🎬 طلبات صناعة المحتوى</h3>
                <div className="text-sm text-gray-600 mb-3">
                  عدد الطلبات: {contentRequests.length}
                </div>
                {contentRequests.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">لا توجد طلبات محتوى</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {contentRequests.map((request) => (
                      <div key={request.id} className="bg-white p-4 rounded-lg border shadow-sm">
                        {/* Request Header */}
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-lg">طلب محتوى #{request.id.slice(-4)}</span>
                            <Badge variant="secondary">قيد المراجعة</Badge>
                          </div>
                          <p className="text-xs text-gray-500">
                            {request.timestamp.toLocaleString('ar-SA')}
                          </p>
                        </div>

                        {/* Request Information - Always Displayed */}
                        <div className="bg-gray-50 p-3 rounded-lg mb-3">
                          <div className="space-y-2">
                            <div>
                              <span className="font-bold text-gray-700">معرف القناة:</span>
                              <p className="text-purple-600 font-medium">{request.channelId}</p>
                            </div>
                            <div>
                              <span className="font-bold text-gray-700">رابط الفيديو:</span>
                              <a 
                                href={request.videoLink} 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="text-blue-600 underline break-all block mt-1 hover:text-blue-800"
                              >
                                {request.videoLink}
                              </a>
                            </div>
                            <div>
                              <span className="font-bold text-gray-700">معرف الطلب:</span>
                              <p className="text-gray-600 font-mono text-sm">{request.id}</p>
                            </div>
                          </div>
                        </div>
                        
                        {/* Action Buttons */}
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => setSelectedUserCode('CONTENT_' + request.id)}
                            className="bg-purple-500 hover:bg-purple-600"
                          >
                            <MessageCircle className="w-3 h-3 ml-1" />
                            رد على الطلب
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => composeEmail(request.channelId, 'content')}
                          >
                            <Mail className="w-3 h-3 ml-1" />
                            إيميل
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>

          {/* Direct Message Composer */}
          {selectedUserCode && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg border-t-4 border-blue-500">
              <h4 className="font-bold mb-2">
                📝 إرسال رسالة للمستخدم: {selectedUserCode}
              </h4>
              <div className="space-y-3">
                <Textarea
                  placeholder="اكتب رسالتك هنا..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  rows={3}
                />
                <div className="flex gap-2">
                  <Button
                    onClick={() => sendDirectMessage(selectedUserCode, messageText)}
                    className="bg-green-500 hover:bg-green-600"
                  >
                    <Send className="w-4 h-4 ml-1" />
                    إرسال الرسالة
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedUserCode('')}
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AdminCommunication;
