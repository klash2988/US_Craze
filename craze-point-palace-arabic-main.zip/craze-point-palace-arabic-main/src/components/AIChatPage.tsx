import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Send, Bot, User, Heart } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';
import { useSounds } from '@/hooks/useSounds';
import { useEnhancedAI } from '@/hooks/useEnhancedAI';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  mood?: 'helpful' | 'romantic' | 'technical' | 'gaming';
}

interface AIChatPageProps {
  onBack: () => void;
}

const AIChatPage = ({ onBack }: AIChatPageProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: '💖 مرحبا حبيبي في UC Craze AI! 🌟\n\nأنا مساعدك الذكي الخاص بتطبيق UC Craze! يمكنني:\n\n🎮 إعطائك أحدث نصائح PUBG والحساسيات\n💕 التحدث معك بشكل رومانسي وودود\n🔧 حل أي مشكلة تقنية في التطبيق\n💡 فهم كلامك العادي تماماً\n🌐 مساعدتك في كل ما يخص UC Craze\n\nأنا جزء من عائلة UC Craze وهنا لخدمتك! ❤️\nماذا تريد أن نتحدث عنه اليوم؟ 😊',
      isBot: true,
      timestamp: new Date(),
      mood: 'helpful'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { language } = useLanguage();
  const { playSound } = useSounds();
  const { generateAdvancedResponse, isProcessing } = useEnhancedAI();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getMoodIcon = (mood?: string) => {
    switch (mood) {
      case 'romantic': return '💕';
      case 'gaming': return '🎮';
      case 'technical': return '🔧';
      default: return '🤖';
    }
  };

  const getMoodColor = (mood?: string) => {
    switch (mood) {
      case 'romantic': return 'from-pink-500 to-rose-500';
      case 'gaming': return 'from-purple-500 to-indigo-500';
      case 'technical': return 'from-blue-500 to-cyan-500';
      default: return 'from-blue-500 to-blue-600';
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading || isProcessing) return;

    playSound('buttonClick');

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputMessage,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputMessage;
    setInputMessage('');
    setIsLoading(true);

    try {
      const aiResponse = await generateAdvancedResponse(currentInput);
      
      playSound('success');
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse.text,
        isBot: true,
        timestamp: new Date(),
        mood: aiResponse.mood
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: 'آسف حبيبي، حدث خطأ في UC Craze AI. جرب مرة أخرى! 💕',
        isBot: true,
        timestamp: new Date(),
        mood: 'helpful'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleBack = () => {
    playSound('pageTransition');
    onBack();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-yellow-400 to-orange-500" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white/20 backdrop-blur-sm border-b border-white/20 p-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full flex items-center justify-center animate-pulse">
              <Heart className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold">💖 UC Craze AI</h1>
              <p className="text-white/70 text-sm">ذكي • رومانسي • مفيد</p>
            </div>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 pb-24" style={{ height: 'calc(100vh - 140px)' }}>
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.isBot ? 'justify-start' : 'justify-end'}`}
            >
              {message.isBot && (
                <div className={`w-8 h-8 bg-gradient-to-r ${getMoodColor(message.mood)} rounded-full flex items-center justify-center flex-shrink-0 mt-1`}>
                  <span className="text-sm">{getMoodIcon(message.mood)}</span>
                </div>
              )}
              
              <div
                className={`max-w-[80%] p-3 rounded-2xl ${
                  message.isBot
                    ? 'bg-white/95 text-gray-800 rounded-tl-none shadow-lg'
                    : 'bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-tr-none shadow-lg'
                }`}
              >
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.text}</p>
                <p className={`text-xs mt-1 ${message.isBot ? 'text-gray-500' : 'text-blue-100'}`}>
                  {message.timestamp.toLocaleTimeString('ar-SA', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </p>
              </div>

              {!message.isBot && (
                <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <User className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          ))}

          {(isLoading || isProcessing) && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1 animate-pulse">
                <span className="text-sm">🧠</span>
              </div>
              <div className="bg-white/95 p-3 rounded-2xl rounded-tl-none shadow-lg">
                <div className="flex gap-1 items-center">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <span className="text-xs text-gray-600 mr-2">أفكر...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/20 backdrop-blur-sm border-t border-white/20 p-4">
        <div className="flex gap-2 items-end">
          <Textarea
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="اكتب رسالتك هنا... تحدث مع UC Craze AI! 💕"
            className="flex-1 min-h-[40px] max-h-[120px] bg-white/95 border-white/30 text-gray-800 placeholder:text-gray-500 resize-none rounded-2xl focus:ring-2 focus:ring-pink-300"
            disabled={isLoading || isProcessing}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isLoading || isProcessing}
            className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white rounded-2xl px-4 py-2 h-auto shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AIChatPage;
