
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface TermsPageProps {
  onBack: () => void;
}

const TermsPage = ({ onBack }: TermsPageProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-yellow-400 to-orange-500 p-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white hover:bg-white/20"
        >
          <ArrowRight className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-white">📄 شروط الاستخدام</h1>
      </div>

      {/* Content */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mx-auto max-w-md shadow-lg">
        <div className="text-right space-y-4 text-gray-800 leading-relaxed">
          <p className="text-lg font-semibold text-green-600">
            ✅ باستخدام هذا التطبيق، فإنك توافق على ما يلي:
          </p>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>عدم استخدام وسائل احتيالية أو إنشاء حسابات متعددة.</span>
            </li>
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>احترام شروط السحب وعدم إساءة استخدام الميزات.</span>
            </li>
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>نحتفظ بحق حظر أو منع المستخدمين المخالفين دون إشعار مسبق.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
