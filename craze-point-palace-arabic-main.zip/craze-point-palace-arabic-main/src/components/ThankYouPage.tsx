
import { useEffect } from 'react';
import { CheckCircle } from 'lucide-react';

interface ThankYouPageProps {
  onNavigate: (screen: string) => void;
}

const ThankYouPage = ({ onNavigate }: ThankYouPageProps) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onNavigate('home');
    }, 4000);

    return () => clearTimeout(timer);
  }, [onNavigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 via-emerald-500 to-teal-600 flex items-center justify-center p-4" dir="rtl">
      <div className="text-center">
        <div className="animate-bounce mb-6">
          <CheckCircle className="w-24 h-24 text-white mx-auto" />
        </div>
        
        <h1 className="text-4xl font-bold text-white mb-4">شكراً لك! 🎉</h1>
        
        <div className="bg-white/20 backdrop-blur-sm rounded-lg p-6 max-w-md mx-auto">
          <p className="text-white text-lg leading-relaxed">
            تم إرسال طلبك بنجاح!
            <br />
            سيتم التواصل معك خلال 24 ساعة.
          </p>
        </div>

        <div className="mt-6">
          <div className="animate-pulse text-white text-sm">
            سيتم العودة للصفحة الرئيسية تلقائياً...
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;
