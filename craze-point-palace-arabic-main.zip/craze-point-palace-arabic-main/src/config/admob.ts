
export const ADMOB_CONFIG = {
  // معرف التطبيق - يجب تعديله لاحقاً
  APP_ID: {
    android: 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX', // ضع معرف تطبيق Android هنا
    ios: 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX' // ضع معرف تطبيق iOS هنا
  },
  
  // معرفات وحدات الإعلانات - يجب تعديلها لاحقاً
  AD_UNITS: {
    // إعلانات المكافآت (Rewarded Ads)
    REWARDED: {
      android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // ضع معرف الإعلان المكافأة لـ Android
      ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX' // ضع معرف الإعلان المكافأة لـ iOS
    },
    
    // إعلانات البانر (Banner Ads) - اختياري
    BANNER: {
      android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
      ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX'
    },
    
    // إعلانات الشاشة الكاملة (Interstitial Ads) - اختياري
    INTERSTITIAL: {
      android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
      ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX'
    }
  },
  
  // إعدادات الاختبار
  TEST_MODE: true, // غير إلى false عند النشر
  TEST_DEVICE_IDS: [] // أضف معرفات الأجهزة للاختبار
};

// دالة للحصول على معرف الإعلان المناسب للمنصة
export const getAdUnitId = (adType: keyof typeof ADMOB_CONFIG.AD_UNITS) => {
  // @ts-ignore - Capacitor will be available in mobile app
  const platform = window.Capacitor?.getPlatform();
  if (platform === 'android') {
    return ADMOB_CONFIG.AD_UNITS[adType].android;
  } else if (platform === 'ios') {
    return ADMOB_CONFIG.AD_UNITS[adType].ios;
  }
  // إذا كان في المتصفح، استخدم معرف Android كافتراضي
  return ADMOB_CONFIG.AD_UNITS[adType].android;
};
